import React, { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useAuth } from "../services/AuthContext";
import { Shield, Key, Mail, User, AlertCircle, Sparkles, LogIn, ArrowRight } from "lucide-react";
import { motion } from "motion/react";

export default function LoginPage() {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const { login, register, loginWithGoogleToken, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  useEffect(() => {
    const token = searchParams.get("token");
    const err = searchParams.get("error");
    if (token) {
      loginWithGoogleToken(token);
      navigate("/dashboard");
    } else if (err) {
      setError(err);
    }
  }, [searchParams, loginWithGoogleToken, navigate]);

  useEffect(() => {
    if (isAuthenticated) {
      navigate("/dashboard");
    }
  }, [isAuthenticated, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      if (isLogin) {
        await login(email, password);
      } else {
        if (!name.trim()) {
          throw new Error("Please enter your full name.");
        }
        await register(email, name, password);
      }
      navigate("/dashboard");
    } catch (err: any) {
      setError(err.message || "Authentication failed. Please check your inputs.");
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = () => {
    window.location.href = "/api/auth/google";
  };

  return (
    <div className="relative min-h-[85vh] flex items-center justify-center px-4 py-12" id="login-container">
      {/* Background Orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#1A73E8]/10 rounded-full filter blur-3xl -z-10 animate-pulse" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-[#9333EA]/10 rounded-full filter blur-3xl -z-10 animate-pulse delay-700" />

      <div className="w-full max-w-md bg-[#0D1527]/80 backdrop-blur-xl border border-slate-800 rounded-2xl p-8 shadow-2xl relative" id="auth-card">
        {/* Decorative Badge */}
        <div className="flex justify-center mb-6">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#1A73E8]/10 border border-[#1A73E8]/20 text-xs text-[#4285F4]">
            <Shield className="w-3.5 h-3.5" />
            <span>Secure Forensic Verification</span>
          </div>
        </div>

        <div className="text-center mb-8">
          <h1 className="text-3xl font-sans font-bold tracking-tight bg-gradient-to-r from-slate-100 to-slate-300 bg-clip-text text-transparent">
            {isLogin ? "Welcome Back" : "Create Account"}
          </h1>
          <p className="text-slate-400 text-sm mt-2">
            {isLogin ? "Access your advanced forensic analyses vault" : "Get started with cryptographic AI deepfake forensic suite"}
          </p>
        </div>

        {error && (
          <div className="flex items-start gap-2.5 p-3.5 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-sm mb-6" id="auth-error-banner">
            <AlertCircle className="w-5 h-5 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Tab Selection */}
        <div className="flex border-b border-slate-800 mb-6" id="auth-tab-bar">
          <button
            id="tab-login"
            type="button"
            className={`flex-1 pb-3 text-sm font-medium transition-colors relative ${isLogin ? "text-slate-100 font-semibold" : "text-slate-500 hover:text-slate-400"}`}
            onClick={() => { setIsLogin(true); setError(""); }}
          >
            Sign In
            {isLogin && <motion.div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#1A73E8]" layoutId="authUnderline" />}
          </button>
          <button
            id="tab-register"
            type="button"
            className={`flex-1 pb-3 text-sm font-medium transition-colors relative ${!isLogin ? "text-slate-100 font-semibold" : "text-slate-500 hover:text-slate-400"}`}
            onClick={() => { setIsLogin(false); setError(""); }}
          >
            Register
            {!isLogin && <motion.div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#1A73E8]" layoutId="authUnderline" />}
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4" id="auth-form">
          {!isLogin && (
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">Full Name</label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-slate-500" />
                <input
                  id="reg-name-input"
                  type="text"
                  required
                  placeholder="John Doe"
                  className="w-full bg-[#080E1C] border border-slate-800 rounded-lg py-2.5 pl-10 pr-4 text-slate-200 text-sm placeholder-slate-600 focus:outline-none focus:border-[#1A73E8] focus:ring-1 focus:ring-[#1A73E8] transition-all"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1.5">Email Address</label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-slate-500" />
              <input
                id="auth-email-input"
                type="email"
                required
                placeholder="you@domain.com"
                className="w-full bg-[#080E1C] border border-slate-800 rounded-lg py-2.5 pl-10 pr-4 text-slate-200 text-sm placeholder-slate-600 focus:outline-none focus:border-[#1A73E8] focus:ring-1 focus:ring-[#1A73E8] transition-all"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1.5">Secure Password</label>
            <div className="relative">
              <Key className="absolute left-3 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-slate-500" />
              <input
                id="auth-password-input"
                type="password"
                required
                placeholder="••••••••"
                className="w-full bg-[#080E1C] border border-slate-800 rounded-lg py-2.5 pl-10 pr-4 text-slate-200 text-sm placeholder-slate-600 focus:outline-none focus:border-[#1A73E8] focus:ring-1 focus:ring-[#1A73E8] transition-all"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
          </div>

          <button
            id="auth-submit-btn"
            type="submit"
            disabled={loading}
            className="w-full bg-gradient-to-r from-[#1A73E8] to-[#1557B0] hover:from-[#1b7dfb] hover:to-[#175ec2] text-white font-medium py-2.5 rounded-lg text-sm transition-all flex items-center justify-center gap-2 shadow-lg shadow-blue-900/20 active:scale-[0.98] disabled:opacity-50 disabled:scale-100"
          >
            {loading ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <>
                <span>{isLogin ? "Sign In to Suite" : "Create Suite Account"}</span>
                {isLogin ? <LogIn className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
              </>
            )}
          </button>
        </form>

        {/* Divider */}
        <div className="relative my-6" id="auth-divider">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-slate-800" />
          </div>
          <div className="relative flex justify-center text-xs uppercase">
            <span className="bg-[#0D1527] px-3 text-slate-500">Or integrate with</span>
          </div>
        </div>

        {/* Google Authentication Button */}
        <button
          id="google-oauth-btn"
          type="button"
          onClick={handleGoogleLogin}
          className="w-full border border-slate-800 bg-[#080E1C] hover:bg-slate-800/40 text-slate-300 font-medium py-2.5 rounded-lg text-sm transition-all flex items-center justify-center gap-2 active:scale-[0.98]"
        >
          <svg className="w-4 h-4" viewBox="0 0 24 24">
            <path
              fill="#4285F4"
              d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
            />
            <path
              fill="#34A853"
              d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
            />
            <path
              fill="#FBBC05"
              d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
            />
            <path
              fill="#EA4335"
              d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
            />
          </svg>
          <span>Continue with Google</span>
        </button>

        <div className="text-center mt-6 text-xs text-slate-500">
          By signing in, you agree to our <span className="underline hover:text-slate-400 cursor-pointer">Forensic Sandbox Agreement</span> and <span className="underline hover:text-slate-400 cursor-pointer">API Policies</span>.
        </div>
      </div>
    </div>
  );
}
