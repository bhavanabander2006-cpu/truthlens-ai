import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { 
  Search, 
  Filter, 
  FileImage, 
  FileAudio, 
  FileVideo, 
  ExternalLink,
  ShieldAlert,
  ShieldCheck,
  RefreshCw,
  Clock,
  BarChart2,
  FolderMinus,
  ArrowRight,
  TrendingUp,
  Cpu,
  UserCheck,
  Loader,
  Download,
  Database,
  Calendar,
  AlertCircle
} from "lucide-react";
import { getAllAnalyses, fetchAnalytics } from "../services/api";
import { AnalysisRecord } from "../types";
import { SAMPLE_PLAYGROUND } from "../data/benchmarks";

interface AnalyticsData {
  totalScans: number;
  aiScans: number;
  humanScans: number;
  scansByDay: Array<{
    date: string;
    total: number;
    ai: number;
    human: number;
  }>;
}

export default function DashboardPage() {
  const [dashboardTab, setDashboardTab] = useState<"history" | "benchmarks" | "analytics">("history");
  const [records, setRecords] = useState<AnalysisRecord[]>([]);
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [analyticsLoading, setAnalyticsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [verdictFilter, setVerdictFilter] = useState<string>("all");
  const [benchmarkFilter, setBenchmarkFilter] = useState<string>("all");

  const fetchRecords = async () => {
    setLoading(true);
    try {
      const data = await getAllAnalyses();
      setRecords(data);
    } catch (error) {
      console.error("Failed to fetch historical logs:", error);
    } finally {
      setLoading(false);
    }
  };

  const loadAnalytics = async () => {
    setAnalyticsLoading(true);
    try {
      const data = await fetchAnalytics();
      setAnalytics(data);
    } catch (err) {
      console.error("Failed to load analytics trends:", err);
    } finally {
      setAnalyticsLoading(false);
    }
  };

  useEffect(() => {
    fetchRecords();
  }, []);

  useEffect(() => {
    if (dashboardTab === "analytics") {
      loadAnalytics();
    }
  }, [dashboardTab]);

  // Filter records
  const filteredRecords = records.filter((rec) => {
    const matchesSearch = rec.file_name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = typeFilter === "all" ? true : rec.file_type === typeFilter;
    const matchesVerdict = verdictFilter === "all" ? true : rec.verdict === verdictFilter;
    return matchesSearch && matchesType && matchesVerdict;
  });

  // Calculate quick stats
  const totalCount = records.length;
  const aiCount = records.filter((r) => r.verdict === "AI-GENERATED").length;
  const humanCount = records.filter((r) => r.verdict === "HUMAN-GENERATED").length;
  
  const getMostCommonType = () => {
    if (totalCount === 0) return "N/A";
    const counts: Record<string, number> = { image: 0, audio: 0, video: 0 };
    records.forEach((r) => {
      counts[r.file_type] = (counts[r.file_type] || 0) + 1;
    });
    
    let maxType = "image";
    let maxVal = -1;
    Object.entries(counts).forEach(([type, val]) => {
      if (val > maxVal) {
        maxVal = val;
        maxType = type;
      }
    });
    return maxType.toUpperCase();
  };

  const mostCommonType = getMostCommonType();

  // Custom SVG Bar Chart calculation helper
  const renderTrendSVG = () => {
    if (!analytics || !analytics.scansByDay || analytics.scansByDay.length === 0) {
      return (
        <div className="flex h-48 items-center justify-center text-xs text-slate-500 font-mono">
          NO TREND LOG DATA RECORDED
        </div>
      );
    }

    const data = analytics.scansByDay;
    const maxVal = Math.max(...data.map(d => d.total), 5); // Default min scale 5
    const width = 500;
    const height = 150;
    const padding = 20;
    const chartWidth = width - padding * 2;
    const chartHeight = height - padding * 2;
    const stepX = chartWidth / (data.length - 1 || 1);

    // Compute coordinate points
    const pointsTotal = data.map((d, i) => `${padding + i * stepX},${padding + chartHeight - (d.total / maxVal) * chartHeight}`).join(" ");
    const pointsAI = data.map((d, i) => `${padding + i * stepX},${padding + chartHeight - (d.ai / maxVal) * chartHeight}`).join(" ");
    const pointsHuman = data.map((d, i) => `${padding + i * stepX},${padding + chartHeight - (d.human / maxVal) * chartHeight}`).join(" ");

    return (
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-full text-slate-500 overflow-visible" id="trend-svg-canvas">
        {/* Grid lines */}
        {[0, 0.25, 0.5, 0.75, 1].map((ratio, idx) => (
          <line
            key={idx}
            x1={padding}
            y1={padding + chartHeight * ratio}
            x2={width - padding}
            y2={padding + chartHeight * ratio}
            stroke="#1E293B"
            strokeWidth={1}
            strokeDasharray="4 4"
          />
        ))}

        {/* Lines */}
        <polyline fill="none" stroke="#64748B" strokeWidth={1.5} points={pointsTotal} />
        <polyline fill="none" stroke="#FF1744" strokeWidth={2} points={pointsAI} />
        <polyline fill="none" stroke="#00C853" strokeWidth={2} points={pointsHuman} />

        {/* Points & Hovers */}
        {data.map((d, i) => {
          const cx = padding + i * stepX;
          const cyT = padding + chartHeight - (d.total / maxVal) * chartHeight;
          const cyA = padding + chartHeight - (d.ai / maxVal) * chartHeight;
          const cyH = padding + chartHeight - (d.human / maxVal) * chartHeight;

          return (
            <g key={i} className="group cursor-pointer">
              <circle cx={cx} cy={cyT} r={3} fill="#64748B" />
              <circle cx={cx} cy={cyA} r={3} fill="#FF1744" />
              <circle cx={cx} cy={cyH} r={3} fill="#00C853" />

              {/* Day Label */}
              <text
                x={cx}
                y={height - 2}
                textAnchor="middle"
                className="text-[8px] font-bold font-mono fill-slate-500 uppercase"
              >
                {d.date.split("-").slice(1).join("/")}
              </text>
            </g>
          );
        })}
      </svg>
    );
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8 space-y-8 bg-[#050A1A]" id="dashboard-container">
      {/* SECTION 1: HEADER */}
      <div className="flex flex-col justify-between items-start gap-4 sm:flex-row sm:items-center">
        <div className="space-y-1">
          <div className="flex items-center space-x-3">
            <h2 className="font-display text-3xl font-extrabold tracking-tight text-white">
              Forensic Vault
            </h2>
            <span className="inline-flex h-6 items-center rounded-full bg-[#1A73E8] px-2.5 text-xs font-bold text-white shadow-sm shadow-blue-900/35">
              {totalCount} Total Runs
            </span>
          </div>
          <p className="text-sm text-[#A8C0E8]">
            Comprehensive logging history and AI-synthesized deepfake risk analytics.
          </p>
        </div>

        <button
          id="refresh-vault-btn"
          onClick={fetchRecords}
          className="flex items-center space-x-1.5 rounded-lg border border-slate-800 bg-white/5 px-4 py-2.5 text-xs font-bold text-white transition-colors hover:bg-white/10"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${loading ? "animate-spin" : ""}`} />
          <span>Refresh Vault</span>
        </button>
      </div>

      {/* SECTION 2: STATS ROW */}
      <div className="grid gap-4 grid-cols-2 lg:grid-cols-4">
        {/* Stat 1: Total */}
        <div className="glass-card rounded-2xl p-5 space-y-2 flex flex-col justify-between bg-[#0A1628] border border-slate-800 shadow-lg">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-bold font-mono uppercase tracking-wider">Total Scanned</span>
            <BarChart2 className="h-4.5 w-4.5 text-[#1A73E8]" />
          </div>
          <div className="space-y-1">
            <p className="text-2xl font-extrabold font-mono text-white">{totalCount}</p>
            <p className="text-[10px] text-[#A8C0E8]">Completed audits</p>
          </div>
        </div>

        {/* Stat 2: AI */}
        <div className="glass-card rounded-2xl p-5 space-y-2 flex flex-col justify-between bg-[#0A1628] border border-slate-800 shadow-lg">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-bold font-mono uppercase tracking-wider">AI-Generated</span>
            <Cpu className="h-4.5 w-4.5 text-red-500" />
          </div>
          <div className="space-y-1">
            <p className="text-2xl font-extrabold font-mono text-white">{aiCount}</p>
            <p className="text-[10px] text-red-400">Deepfakes detected</p>
          </div>
        </div>

        {/* Stat 3: Human */}
        <div className="glass-card rounded-2xl p-5 space-y-2 flex flex-col justify-between bg-[#0A1628] border border-slate-800 shadow-lg">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-bold font-mono uppercase tracking-wider">Human-Captured</span>
            <UserCheck className="h-4.5 w-4.5 text-emerald-500" />
          </div>
          <div className="space-y-1">
            <p className="text-2xl font-extrabold font-mono text-white">{humanCount}</p>
            <p className="text-[10px] text-emerald-400">Authentic materials</p>
          </div>
        </div>

        {/* Stat 4: Common File */}
        <div className="glass-card rounded-2xl p-5 space-y-2 flex flex-col justify-between bg-[#0A1628] border border-slate-800 shadow-lg">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-bold font-mono uppercase tracking-wider">Dominant Media</span>
            <TrendingUp className="h-4.5 w-4.5 text-[#1A73E8]" />
          </div>
          <div className="space-y-1">
            <p className="text-2xl font-extrabold font-mono text-white">{mostCommonType}</p>
            <p className="text-[10px] text-slate-400">Active verification type</p>
          </div>
        </div>
      </div>

      {/* SECTION 2.5: TAB SWITCHER */}
      <div className="flex border-b border-slate-800 overflow-x-auto whitespace-nowrap" id="dashboard-tab-bar">
        <button
          id="dashboard-tab-history"
          onClick={() => { setDashboardTab("history"); setSearchQuery(""); }}
          className={`flex items-center space-x-2 border-b-2 px-6 py-3.5 text-sm font-bold transition-all cursor-pointer ${
            dashboardTab === "history"
              ? "border-[#1A73E8] text-white bg-slate-900/40 font-extrabold"
              : "border-transparent text-slate-400 hover:text-white hover:bg-white/5"
          }`}
        >
          <Database className="h-4 w-4 shrink-0" />
          <span>Audit Logs ({records.length})</span>
        </button>

        <button
          id="dashboard-tab-analytics"
          onClick={() => { setDashboardTab("analytics"); setSearchQuery(""); }}
          className={`flex items-center space-x-2 border-b-2 px-6 py-3.5 text-sm font-bold transition-all cursor-pointer ${
            dashboardTab === "analytics"
              ? "border-[#1A73E8] text-white bg-slate-900/40 font-extrabold"
              : "border-transparent text-slate-400 hover:text-white hover:bg-white/5"
          }`}
        >
          <BarChart2 className="h-4 w-4 shrink-0" />
          <span>7-Day Trends & Insights</span>
        </button>

        <button
          id="dashboard-tab-benchmarks"
          onClick={() => { setDashboardTab("benchmarks"); setSearchQuery(""); }}
          className={`flex items-center space-x-2 border-b-2 px-6 py-3.5 text-sm font-bold transition-all cursor-pointer ${
            dashboardTab === "benchmarks"
              ? "border-[#1A73E8] text-white bg-slate-900/40 font-extrabold"
              : "border-transparent text-slate-400 hover:text-white hover:bg-white/5"
          }`}
        >
          <Cpu className="h-4 w-4 shrink-0" />
          <span>Standard Benchmarks</span>
        </button>
      </div>

      {/* SECTION 3: AUDIT HISTORY LOGS */}
      {dashboardTab === "history" && (
        <div className="space-y-6" id="dashboard-history-tab">
          <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-4 items-center p-4 rounded-2xl bg-[#0A1628] border border-slate-800">
            {/* Search */}
            <div className="relative md:col-span-2">
              <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
              <input
                id="history-search-input"
                type="text"
                placeholder="Filter logs by filename..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full rounded-xl border border-slate-800 bg-[#050A1A] py-3 pl-11 pr-4 text-xs text-white placeholder-slate-600 outline-none focus:border-[#1A73E8]"
              />
            </div>

            {/* Type Filter */}
            <div className="relative">
              <Filter className="absolute left-3.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-500" />
              <select
                id="history-type-filter"
                value={typeFilter}
                onChange={(e) => setTypeFilter(e.target.value)}
                className="w-full appearance-none rounded-xl border border-slate-800 bg-[#050A1A] py-3 pl-11 pr-8 text-xs text-white outline-none focus:border-[#1A73E8]"
              >
                <option value="all">All Media</option>
                <option value="image">Images Only</option>
                <option value="audio">Audios Only</option>
                <option value="video">Videos Only</option>
              </select>
            </div>

            {/* Verdict Filter */}
            <div className="relative">
              <Filter className="absolute left-3.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-500" />
              <select
                id="history-verdict-filter"
                value={verdictFilter}
                onChange={(e) => setVerdictFilter(e.target.value)}
                className="w-full appearance-none rounded-xl border border-slate-800 bg-[#050A1A] py-3 pl-11 pr-8 text-xs text-white outline-none focus:border-[#1A73E8]"
              >
                <option value="all">All Verdicts</option>
                <option value="AI-GENERATED">Deepfakes Only</option>
                <option value="HUMAN-GENERATED">Authentic Only</option>
              </select>
            </div>
          </div>

          {loading ? (
            <div className="flex justify-center items-center py-24" id="history-loading-spinner">
              <Loader className="h-8 w-8 animate-spin text-[#1A73E8]" />
            </div>
          ) : filteredRecords.length === 0 ? (
            <div className="glass-card rounded-2xl p-12 text-center max-w-md mx-auto space-y-6 border-dashed border-slate-800" id="history-empty-view">
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-white/5 text-slate-700">
                <FolderMinus className="h-10 w-10" />
              </div>
              <div className="space-y-1">
                <h4 className="font-display font-bold text-white text-base">No Matching Records</h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  No matching record signatures were found in the database.
                </p>
              </div>
              <Link
                id="empty-nav-detect-btn"
                to="/detect"
                className="inline-flex items-center space-x-2 rounded-xl bg-[#1A73E8] px-5 py-3 font-display text-xs font-bold text-white shadow-lg shadow-blue-900/35 hover:bg-[#0D47A1]"
              >
                <span>Initiate New Verification</span>
                <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            </div>
          ) : (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3" id="history-records-grid">
              {filteredRecords.map((rec) => {
                const isAi = rec.verdict === "AI-GENERATED";
                return (
                  <div 
                    key={rec.id}
                    className="glass-card rounded-2xl p-6 flex flex-col justify-between transition-all bg-[#0A1628] border border-slate-800 hover:border-slate-700 shadow-xl"
                  >
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        {isAi ? (
                          <span className="inline-flex items-center space-x-1 rounded-md px-2 py-0.5 text-[9px] font-bold tracking-wider uppercase bg-red-950/40 border border-red-500/30 text-red-400">
                            <ShieldAlert className="h-3 w-3 shrink-0" />
                            <span>DEEPFAKE</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center space-x-1 rounded-md px-2 py-0.5 text-[9px] font-bold tracking-wider uppercase bg-emerald-950/40 border border-emerald-500/30 text-emerald-400">
                            <ShieldCheck className="h-3 w-3 shrink-0" />
                            <span>AUTHENTIC</span>
                          </span>
                        )}
                        
                        <span className="text-[10px] font-mono text-slate-500 flex items-center space-x-1">
                          <Clock className="h-3 w-3" />
                          <span>{new Date(rec.timestamp).toLocaleDateString()}</span>
                        </span>
                      </div>

                      <div className="space-y-1">
                        <h4 className="font-display font-bold text-white text-sm truncate" title={rec.file_name}>
                          {rec.file_name}
                        </h4>
                        <div className="flex items-center space-x-2 text-[11px] text-slate-400 font-mono">
                          <span className="uppercase flex items-center space-x-1 text-[#1A73E8]">
                            {rec.file_type === "image" && <FileImage className="h-3 w-3" />}
                            {rec.file_type === "audio" && <FileAudio className="h-3 w-3" />}
                            {rec.file_type === "video" && <FileVideo className="h-3 w-3" />}
                            <span className="text-slate-400">{rec.file_type}</span>
                          </span>
                          {rec.file_size && (
                            <>
                              <span className="text-slate-700">•</span>
                              <span>{rec.file_size}</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-between gap-4">
                      <div>
                        <p className="text-[9px] text-slate-500 uppercase tracking-wider font-mono">Confidence</p>
                        <p className="text-base font-bold font-mono text-[#1A73E8]">
                          {rec.confidence_score}%
                        </p>
                      </div>

                      <Link
                        id={`view-rec-${rec.id}-btn`}
                        to={`/results/${rec.id}`}
                        className="inline-flex items-center space-x-1.5 rounded-lg bg-[#1A73E8] px-3.5 py-2 text-xs font-semibold text-white hover:bg-[#0D47A1] transition-all"
                      >
                        <span>View Verdict</span>
                        <ExternalLink className="h-3.5 w-3.5" />
                      </Link>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* SECTION 4: ANALYTICS DASHBOARD TAB */}
      {dashboardTab === "analytics" && (
        <div className="space-y-8" id="dashboard-analytics-tab">
          <div className="grid gap-6 md:grid-cols-3">
            {/* Chart Column */}
            <div className="md:col-span-2 glass-card rounded-2xl p-6 bg-[#0A1628] border border-slate-800 shadow-xl space-y-6">
              <div>
                <h3 className="font-display text-lg font-extrabold text-white">7-Day Verification Trend</h3>
                <p className="text-xs text-slate-400 mt-0.5">Chronological frequency of neural audits and synthetic classification match ratios</p>
              </div>

              {analyticsLoading ? (
                <div className="flex h-56 items-center justify-center">
                  <Loader className="w-8 h-8 animate-spin text-[#1A73E8]" />
                </div>
              ) : (
                <div className="h-56 p-2 bg-slate-950/50 border border-slate-800 rounded-xl relative flex items-center justify-center">
                  {renderTrendSVG()}
                </div>
              )}

              {/* Chart Legend */}
              <div className="flex flex-wrap gap-4 items-center justify-center text-[11px] font-mono border-t border-slate-850 pt-4">
                <span className="flex items-center gap-1.5 text-slate-400">
                  <span className="h-2 w-2 rounded-full bg-slate-500" />
                  <span>TOTAL SCANS</span>
                </span>
                <span className="flex items-center gap-1.5 text-red-400">
                  <span className="h-2 w-2 rounded-full bg-[#FF1744]" />
                  <span>DEEPFAKES MATCHED</span>
                </span>
                <span className="flex items-center gap-1.5 text-emerald-400">
                  <span className="h-2 w-2 rounded-full bg-[#00C853]" />
                  <span>HUMAN CAPTURES</span>
                </span>
              </div>
            </div>

            {/* Distribution Summary Card */}
            <div className="glass-card rounded-2xl p-6 bg-[#0A1628] border border-slate-800 shadow-xl flex flex-col justify-between">
              <div className="space-y-4">
                <h3 className="font-display text-base font-extrabold text-white">Forensic Ratio</h3>
                <p className="text-xs text-slate-400 leading-relaxed">Percentage split of AI synthesized deepfakes compared to native assets.</p>

                {analytics ? (
                  <div className="space-y-4 pt-2">
                    {/* Progress Bar for AI */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs font-mono">
                        <span className="text-red-400">AI-Generated Deepfakes</span>
                        <span className="text-white font-bold">
                          {analytics.totalScans ? Math.round((analytics.aiScans / analytics.totalScans) * 100) : 0}%
                        </span>
                      </div>
                      <div className="h-2 bg-slate-950 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-red-500" 
                          style={{ width: `${analytics.totalScans ? (analytics.aiScans / analytics.totalScans) * 100 : 0}%` }}
                        />
                      </div>
                    </div>

                    {/* Progress Bar for Human */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs font-mono">
                        <span className="text-emerald-400">Human-Generated</span>
                        <span className="text-white font-bold">
                          {analytics.totalScans ? Math.round((analytics.humanScans / analytics.totalScans) * 100) : 0}%
                        </span>
                      </div>
                      <div className="h-2 bg-slate-950 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-emerald-500" 
                          style={{ width: `${analytics.totalScans ? (analytics.humanScans / analytics.totalScans) * 100 : 0}%` }}
                        />
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="flex h-24 items-center justify-center text-slate-600 font-mono text-xs">NO METRIC DATA</div>
                )}
              </div>

              <div className="p-3 bg-slate-900/60 border border-slate-850 rounded-xl text-[10.5px] text-slate-400 leading-normal flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-[#1A73E8] shrink-0 mt-0.5" />
                <span>Deepfake matches are heavily weighted by the synthetic spectral flatness index.</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 5: BENCHMARKS TAB */}
      {dashboardTab === "benchmarks" && (
        <div className="space-y-6" id="dashboard-benchmarks-tab">
          <div className="grid gap-4 sm:grid-cols-3 items-center p-4 rounded-2xl bg-[#0A1628] border border-slate-800">
            {/* Search */}
            <div className="relative sm:col-span-2">
              <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
              <input
                id="benchmarks-search-input"
                type="text"
                placeholder="Search benchmarks by model, creator, or prompt..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full rounded-xl border border-slate-800 bg-[#050A1A] py-3 pl-11 pr-4 text-xs text-white placeholder-slate-600 outline-none focus:border-[#1A73E8]"
              />
            </div>

            {/* Media Format Filter */}
            <div className="relative">
              <Filter className="absolute left-3.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-500" />
              <select
                id="benchmarks-format-filter"
                value={benchmarkFilter}
                onChange={(e) => setBenchmarkFilter(e.target.value)}
                className="w-full appearance-none rounded-xl border border-slate-800 bg-[#050A1A] py-3 pl-11 pr-8 text-xs text-white outline-none focus:border-[#1A73E8]"
              >
                <option value="all">All Formats</option>
                <option value="image">Images Only</option>
                <option value="audio">Audios Only</option>
                <option value="video">Videos Only</option>
              </select>
            </div>
          </div>

          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3" id="benchmarks-cards-grid">
            {(["image", "audio", "video"] as const)
              .filter((type) => benchmarkFilter === "all" || benchmarkFilter === type)
              .flatMap((type) => 
                SAMPLE_PLAYGROUND[type]
                  .filter((sample) => 
                    sample.label.toLowerCase().includes(searchQuery.toLowerCase()) ||
                    sample.desc.toLowerCase().includes(searchQuery.toLowerCase()) ||
                    sample.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                    sample.model.toLowerCase().includes(searchQuery.toLowerCase())
                  )
                  .map((sample) => ({ ...sample, media_type: type }))
              )
              .map((sample) => {
                const isAi = sample.type === "AI-GENERATED";
                return (
                  <div
                    key={sample.name}
                    className="glass-card rounded-2xl p-6 flex flex-col justify-between transition-all bg-[#0A1628] border border-slate-800 hover:border-slate-700 shadow-xl"
                  >
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        {isAi ? (
                          <span className="inline-flex items-center space-x-1 rounded-md px-2 py-0.5 text-[9px] font-bold tracking-wider uppercase bg-red-950/40 border border-red-500/30 text-red-400">
                            <ShieldAlert className="h-3 w-3 shrink-0" />
                            <span>AI-GENERATED</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center space-x-1 rounded-md px-2 py-0.5 text-[9px] font-bold tracking-wider uppercase bg-emerald-950/40 border border-emerald-500/30 text-emerald-400">
                            <ShieldCheck className="h-3 w-3 shrink-0" />
                            <span>HUMAN-CAPTURED</span>
                          </span>
                        )}

                        <span className="text-[10px] font-mono text-slate-500 uppercase flex items-center space-x-1">
                          {sample.media_type === "image" && <FileImage className="h-3 w-3 text-[#1A73E8]" />}
                          {sample.media_type === "audio" && <FileAudio className="h-3 w-3 text-[#1A73E8]" />}
                          {sample.media_type === "video" && <FileVideo className="h-3 w-3 text-[#1A73E8]" />}
                          <span>{sample.media_type}</span>
                        </span>
                      </div>

                      <div className="space-y-1">
                        <h4 className="font-display font-bold text-white text-sm truncate" title={sample.label}>
                          {sample.label}
                        </h4>
                        <p className="text-[11px] font-mono text-[#1A73E8] truncate" title={sample.name}>
                          {sample.name}
                        </p>
                      </div>

                      <p className="text-xs text-slate-400 leading-relaxed line-clamp-2" title={sample.desc}>
                        {sample.desc}
                      </p>
                    </div>

                    <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-between gap-4">
                      <div className="min-w-0 flex-1">
                        <p className="text-[9px] text-slate-500 uppercase tracking-wider font-mono">FORENSIC SIGNAL</p>
                        <p className="text-xs font-semibold font-mono text-[#A8C0E8] truncate" title={sample.model}>
                          {sample.model}
                        </p>
                      </div>

                      <a
                        id={`download-benchmark-${sample.name.replace(/\.[^/.]+$/, "")}-btn`}
                        href={`/samples/${sample.name}`}
                        download={sample.name}
                        className="inline-flex items-center space-x-1.5 rounded-lg bg-[#1A73E8] px-3 py-2 text-xs font-semibold text-white hover:bg-[#0D47A1] transition-all shrink-0 shadow-md shadow-blue-500/10 cursor-pointer"
                      >
                        <Download className="h-3.5 w-3.5" />
                        <span>Download</span>
                      </a>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      )}
    </div>
  );
}
