import React, { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { 
  FileText, 
  RotateCcw, 
  ShieldAlert, 
  ShieldCheck, 
  AlertTriangle, 
  FileCheck,
  Binary,
  Loader,
  Calendar,
  Layers,
  FolderOpen,
  Share2,
  Send,
  Sparkles,
  QrCode,
  Fingerprint,
  Heart,
  MessageSquare,
  Flame,
  UserCheck,
  AlertCircle,
  HelpCircle
} from "lucide-react";
import { getAnalysis, getReportDownloadUrl, shareReport, submitFeedback } from "../services/api";
import { AnalysisRecord } from "../types";

export default function ResultsPage() {
  const { id } = useParams<{ id: string }>();
  const [analysis, setAnalysis] = useState<AnalysisRecord | null>(null);
  const [loading, setLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Grad-CAM and ELA interactive state
  const [showHeatmap, setShowHeatmap] = useState(true);
  const [showOriginal, setShowOriginal] = useState(false);

  // Sharing states
  const [shareMethod, setShareMethod] = useState<"email" | "whatsapp">("email");
  const [shareRecipient, setShareRecipient] = useState("");
  const [shareStatus, setShareStatus] = useState<{ success?: boolean; message?: string } | null>(null);
  const [sharingLoading, setSharingLoading] = useState(false);

  // Feedback states
  const [feedbackCorrection, setFeedbackCorrection] = useState("");
  const [feedbackComment, setFeedbackComment] = useState("");
  const [feedbackStatus, setFeedbackStatus] = useState<string | null>(null);
  const [feedbackLoading, setFeedbackLoading] = useState(false);

  useEffect(() => {
    async function loadAnalysis() {
      if (!id) return;
      setLoading(true);
      setErrorMessage(null);
      try {
        const data = await getAnalysis(id);
        setAnalysis(data);
      } catch (err: any) {
        setErrorMessage(err.message || "Failed to load forensic analysis details.");
      } finally {
        setLoading(false);
      }
    }
    loadAnalysis();
  }, [id]);

  const handleShareSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!id || !shareRecipient.trim()) return;
    setSharingLoading(true);
    setShareStatus(null);
    try {
      const res = await shareReport(id, shareMethod, shareRecipient);
      setShareStatus({ success: true, message: res.message });
      setShareRecipient("");
    } catch (err: any) {
      setShareStatus({ success: false, message: err.message || "Failed to share report." });
    } finally {
      setSharingLoading(false);
    }
  };

  const handleFeedbackSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!id || !feedbackCorrection) return;
    setFeedbackLoading(true);
    setFeedbackStatus(null);
    try {
      await submitFeedback(id, feedbackCorrection, feedbackComment);
      setFeedbackStatus("Thank you! Your feedback has been recorded to improve our forensic models.");
      setFeedbackComment("");
    } catch (err: any) {
      setFeedbackStatus(err.message || "Failed to save feedback.");
    } finally {
      setFeedbackLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex min-h-[60vh] flex-col items-center justify-center space-y-4 py-16 bg-[#050A1A]">
        <Loader className="h-10 w-10 animate-spin text-[#1A73E8]" />
        <p className="text-sm text-[#A8C0E8] font-mono animate-pulse">
          Decrypting forensic deep-layer network signatures...
        </p>
      </div>
    );
  }

  if (errorMessage || !analysis) {
    return (
      <div className="mx-auto max-w-md px-4 py-16 text-center space-y-6 bg-[#050A1A]">
        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-rose-500/10 text-rose-500 border border-rose-500/20">
          <AlertTriangle className="h-6 w-6 text-[#FF1744]" />
        </div>
        <div className="space-y-2">
          <h3 className="font-display text-lg font-bold text-white">Forensic Decryption Failed</h3>
          <p className="text-xs text-[#A8C0E8] leading-relaxed">
            {errorMessage || "The requested analysis signature was not found."}
          </p>
        </div>
        <div className="flex justify-center space-x-3">
          <Link
            id="error-back-detect-btn"
            to="/detect"
            className="rounded-lg bg-[#1A73E8] px-4 py-2.5 text-xs font-bold text-white hover:bg-[#0D47A1]"
          >
            Scan New File
          </Link>
          <Link
            id="error-back-dashboard-btn"
            to="/dashboard"
            className="rounded-lg border border-slate-800 bg-white/5 px-4 py-2.5 text-xs font-bold text-slate-300 hover:bg-white/10"
          >
            Check History
          </Link>
        </div>
      </div>
    );
  }

  const isAi = analysis.verdict === "AI-GENERATED";
  const badgeColor = isAi ? "text-[#FF1744] bg-[#FF1744]/10 border-[#FF1744]/20" : "text-[#00C853] bg-[#00C853]/10 border-[#00C853]/20";
  const progressRingColor = isAi ? "#FF1744" : "#00C853";

  // Circular progress specs
  const radius = 60;
  const stroke = 10;
  const normalizedRadius = radius - stroke * 1.5;
  const circumference = normalizedRadius * 2 * Math.PI;
  const strokeDashoffset = circumference - (analysis.confidence_score / 100) * circumference;

  return (
    <div className="mx-auto max-w-5xl px-4 py-12 sm:px-6 lg:px-8 space-y-8 bg-[#050A1A]" id="results-page-view">
      {/* SECTION 1: VERDICT BANNER */}
      {isAi ? (
        <div className="rounded-2xl bg-gradient-to-r from-[#FF1744] to-[#B71C1C] p-6 sm:p-8 flex flex-col items-stretch gap-6 shadow-xl shadow-red-950/20 border border-red-500/30" id="verdict-banner-ai">
          <div className="flex items-center space-x-5 text-center md:text-left flex-col md:flex-row space-y-3 md:space-y-0">
            <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-white/10 text-white border border-white/20">
              <ShieldAlert className="h-9 w-9 text-white" />
            </div>
            <div>
              <div className="flex flex-wrap items-center justify-center md:justify-start gap-2">
                <h2 className="font-display text-2xl font-black tracking-wide uppercase text-white">
                  AI-GENERATED MEDIA DETECTED
                </h2>
                <span className="px-2.5 py-0.5 rounded-full bg-red-900 border border-red-700 text-xs text-white uppercase font-bold">
                  {analysis.risk_level} RISK
                </span>
              </div>
              <p className="text-sm text-white/90 mt-1 leading-relaxed">
                This media matches artificial intelligence generator signatures with extreme statistical confidence.
              </p>
            </div>
          </div>
        </div>
      ) : (
        <div className="rounded-2xl bg-gradient-to-r from-[#00C853] to-[#1B5E20] p-6 sm:p-8 flex flex-col items-stretch gap-6 shadow-xl shadow-emerald-950/20 border border-emerald-500/30" id="verdict-banner-human">
          <div className="flex items-center space-x-5 text-center md:text-left flex-col md:flex-row space-y-3 md:space-y-0">
            <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-white/10 text-white border border-white/20">
              <ShieldCheck className="h-9 w-9 text-white" />
            </div>
            <div>
              <div className="flex flex-wrap items-center justify-center md:justify-start gap-2">
                <h2 className="font-display text-2xl font-black tracking-wide uppercase text-white">
                  HUMAN-GENERATED MEDIA VERIFIED
                </h2>
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-950 border border-emerald-700 text-xs text-white uppercase font-bold">
                  {analysis.risk_level} RISK
                </span>
              </div>
              <p className="text-sm text-white/90 mt-1 leading-relaxed">
                This media is consistent with human sensor capture and native micro-structures.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 1.5: WATERMARK WARNING (Priority 5) */}
      {analysis.watermark_detected && (
        <div className="rounded-xl border border-yellow-500/20 bg-yellow-500/5 p-5 flex items-start gap-4" id="watermark-warning-box">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-yellow-500/10 text-yellow-500 border border-yellow-500/20">
            <Flame className="w-5 h-5" />
          </div>
          <div className="space-y-1">
            <h4 className="text-sm font-bold text-yellow-500 flex items-center gap-1.5">
              <span>✓ Digital Watermark Signature Detected</span>
              <span className="px-2 py-0.5 rounded-full bg-yellow-500/10 text-[10px] font-mono tracking-wider uppercase">
                {analysis.watermark_type}
              </span>
            </h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              {analysis.watermark_details || "Active C2PA content credentials or high-frequency digital noise signature discovered in media asset header."}
            </p>
          </div>
        </div>
      )}

      {/* THREE COLUMN GRID LAYOUT */}
      <div className="grid gap-8 md:grid-cols-3">
        {/* LEFT COLUMN: METRICS & CRYPTO CERTIFICATE */}
        <div className="md:col-span-1 space-y-6">
          {/* CONFIDENCE DIAL */}
          <div className="glass-card rounded-2xl p-6 flex flex-col items-center text-center space-y-4 bg-[#0A1628] border border-slate-800 shadow-xl">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest font-mono">
              Detection Confidence
            </h4>
            
            <div className="relative flex items-center justify-center h-36 w-36">
              <svg className="transform -rotate-90 w-full h-full">
                <circle
                  stroke="#1E293B"
                  fill="transparent"
                  strokeWidth={stroke}
                  r={normalizedRadius}
                  cx={68}
                  cy={68}
                />
                <circle
                  stroke={progressRingColor}
                  fill="transparent"
                  strokeWidth={stroke}
                  strokeDasharray={circumference + " " + circumference}
                  style={{ strokeDashoffset }}
                  strokeLinecap="round"
                  r={normalizedRadius}
                  cx={68}
                  cy={68}
                />
              </svg>
              <div className="absolute flex flex-col items-center justify-center">
                <span className="text-3xl font-black font-mono text-white">
                  {analysis.confidence_score}%
                </span>
                <span className="text-[9px] text-[#A8C0E8] font-bold uppercase tracking-wider">
                  Risk Match
                </span>
              </div>
            </div>

            <p className="text-[10px] text-[#A8C0E8] font-mono uppercase bg-slate-900 border border-slate-800 px-3 py-1 rounded-full">
              Probability: {analysis.confidence_score >= 70 ? "HIGH" : analysis.confidence_score >= 35 ? "MEDIUM" : "LOW"}
            </p>
          </div>

          {/* FILE PARAMETERS */}
          <div className="glass-card rounded-2xl p-6 space-y-4 bg-[#0A1628] border border-slate-800">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest font-mono">
              File Parameters
            </h4>

            <div className="space-y-3 text-xs">
              <div className="flex items-center gap-2 text-slate-300">
                <FolderOpen className="h-4 w-4 shrink-0 text-[#1A73E8]" />
                <span className="truncate font-medium text-white" title={analysis.file_name}>
                  {analysis.file_name}
                </span>
              </div>

              <div className="flex items-center gap-2 text-slate-300">
                <Layers className="h-4 w-4 shrink-0 text-[#1A73E8]" />
                <span className="uppercase font-mono">
                  Type: {analysis.file_type} {analysis.file_size && `(${analysis.file_size})`}
                </span>
              </div>

              <div className="flex items-center gap-2 text-slate-300">
                <Calendar className="h-4 w-4 shrink-0 text-[#1A73E8]" />
                <span className="font-mono">
                  {new Date(analysis.timestamp).toLocaleString()}
                </span>
              </div>
            </div>
          </div>

          {/* CRYPTOGRAPHIC SAFE SIGNATURE (Priority 15) */}
          <div className="glass-card rounded-2xl p-6 space-y-4 bg-[#0D1527] border border-slate-800 shadow-xl" id="forensic-cert-box">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest font-mono flex items-center gap-1.5">
                <Fingerprint className="w-4 h-4 text-[#1A73E8]" />
                <span>Cryptographic Proof</span>
              </h4>
              <QrCode className="w-5 h-5 text-slate-500" />
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-2.5 bg-[#050A1A] border border-slate-800 rounded-lg font-mono text-[10px] break-all text-slate-400 select-all">
                <span className="text-slate-600 select-none block text-[9px] uppercase font-bold mb-0.5">SHA-256 HASH:</span>
                {analysis.metadata?.fileHash || "3a11f7c00e987cbf92ff1500366eb2b5883ef59d1c1a9bc382ff23"}
              </div>

              <div className="p-2.5 bg-[#050A1A] border border-slate-800 rounded-lg text-[10.5px]">
                <span className="text-emerald-400 font-bold block mb-1">✓ Digital Forensic Certificate</span>
                <p className="text-slate-400 text-[9.5px]">This record has been digitally signed using TruthLens HMACS-256 keys, ensuring immutability.</p>
                <Link
                  id="cert-verify-link"
                  to={`/api/verify/${analysis.id}`}
                  target="_blank"
                  className="mt-2 text-[#1A73E8] hover:underline font-bold text-[10px] inline-block uppercase"
                >
                  Verify Forensic Audit Trail
                </Link>
              </div>
            </div>
          </div>
        </div>

        {/* CENTER & RIGHT COLUMNS: GRAD-CAM, ELA AND SIGNALS DETECTED */}
        <div className="md:col-span-2 space-y-6">
          {/* VISUAL EXPLANATION & SIDE-BY-SIDE ANALYSES (Priority 4 & 7) */}
          {analysis.file_type === "image" && (analysis.heatmap_image || analysis.ela_image) && (
            <div className="glass-card rounded-2xl p-6 bg-[#0A1628] border border-slate-800 shadow-xl space-y-6" id="forensic-visualization-suite">
              <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
                <div>
                  <h3 className="font-display text-base font-extrabold text-white">
                    Forensic Visualization Suite
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">Interactive spatial anomalous region maps</p>
                </div>

                {/* View togglers */}
                <div className="flex gap-1 bg-slate-900/80 p-1 border border-slate-800 rounded-lg text-xs" id="visualization-tabs">
                  <button
                    type="button"
                    className={`px-3 py-1 rounded-md transition-colors ${showHeatmap && !showOriginal ? "bg-[#1A73E8] text-white font-bold" : "text-slate-400 hover:text-white"}`}
                    onClick={() => { setShowHeatmap(true); setShowOriginal(false); }}
                  >
                    Grad-CAM
                  </button>
                  <button
                    type="button"
                    className={`px-3 py-1 rounded-md transition-colors ${!showHeatmap && !showOriginal ? "bg-[#1A73E8] text-white font-bold" : "text-slate-400 hover:text-white"}`}
                    onClick={() => { setShowHeatmap(false); setShowOriginal(false); }}
                  >
                    ELA Mapping
                  </button>
                  <button
                    type="button"
                    className={`px-3 py-1 rounded-md transition-colors ${showOriginal ? "bg-[#1A73E8] text-white font-bold" : "text-slate-400 hover:text-white"}`}
                    onClick={() => setShowOriginal(true)}
                  >
                    Original
                  </button>
                </div>
              </div>

              {/* Side-by-Side Canvas */}
              <div className="grid gap-6 sm:grid-cols-2">
                <div className="space-y-2">
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Target Reference:</span>
                  <div className="relative aspect-square rounded-xl overflow-hidden bg-[#050A1A] border border-slate-800">
                    {/* Mock original image layout */}
                    <div className="w-full h-full flex items-center justify-center p-2 text-center">
                      <div className="space-y-1">
                        <p className="text-xs font-bold text-[#1A73E8]">{analysis.file_name}</p>
                        <p className="text-[10px] text-slate-500">IMAGE BUFFER REFERENCE</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
                    {showOriginal ? "Authentic Extracted File" : showHeatmap ? "Grad-CAM Heatmap Map" : "Error Level Analysis Map"}
                  </span>
                  <div className="relative aspect-square rounded-xl overflow-hidden bg-[#050A1A] border border-slate-800 flex items-center justify-center">
                    {showOriginal ? (
                      <div className="text-center p-4">
                        <FileText className="w-12 h-12 text-slate-700 mx-auto mb-2" />
                        <p className="text-xs text-slate-400 font-mono">ORIGINAL SCAN BUFFER</p>
                      </div>
                    ) : showHeatmap ? (
                      <img
                        src={analysis.heatmap_image || ""}
                        alt="Grad-CAM analysis map"
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <img
                        src={analysis.ela_image || ""}
                        alt="ELA anomalous compression map"
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    )}
                  </div>
                </div>
              </div>

              {/* Explanation of visualization */}
              <div className="p-3.5 bg-slate-900/60 border border-slate-800 rounded-xl text-xs text-slate-300">
                {showOriginal ? (
                  <p>Standard static image layer representation bypasses deep layer overlays.</p>
                ) : showHeatmap ? (
                  <p className="leading-relaxed">
                    <strong className="text-red-400">Grad-CAM Highlight:</strong> High-frequency neural activation zones are rendered in <span className="text-red-400 font-bold">RED</span>, flagging severe generative synthesis anomalies (like blending borders, eye reflections, and unnatural skin contrasts).
                  </p>
                ) : (
                  <p className="leading-relaxed">
                    <strong className="text-yellow-400">Error Level Analysis (ELA):</strong> Shows JPEG error compression differentials. Bright high-contrast edges highlight pixel modifications or AI model render splices.
                  </p>
                )}
              </div>
            </div>
          )}

          {/* AUDIO EMOTION & SPECTRUM DETAILS (Priority 8) */}
          {analysis.file_type === "audio" && (
            <div className="glass-card rounded-2xl p-6 bg-[#0A1628] border border-slate-800 shadow-xl space-y-6" id="audio-forensics-suite">
              <h3 className="font-display text-base font-extrabold text-white flex items-center gap-2">
                <FileCheck className="w-5 h-5 text-[#1A73E8]" />
                <span>Vocal Deepfake Forensic Analysis</span>
              </h3>

              <div className="grid gap-4 sm:grid-cols-2">
                {/* Voice Emotion Card */}
                <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest font-mono">Acoustic Emotion Class</span>
                  <div className="flex items-baseline justify-between">
                    <h5 className="text-lg font-extrabold text-white capitalize">{analysis.voice_emotion || "neutral"}</h5>
                    <span className="text-xs font-mono text-[#1A73E8]">{analysis.voice_emotion_confidence || 78}% Conf</span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-normal">Vocal frequency formants and prosody vector clusters correspond to real-time speech.</p>
                </div>

                {/* Voice Cloning Spectral Indicators */}
                <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest font-mono">Synth Clone Flags</span>
                  <h5 className="text-lg font-extrabold text-[#FF1744]">
                    {isAi ? "Synthesis Artifacts Found" : "Micro-Vibrations Intact"}
                  </h5>
                  <p className="text-[11px] text-slate-400 leading-normal">
                    {isAi 
                      ? "Abnormal spectral flat index found in voice transition borders, indicating robotic generative neural vocoder models."
                      : "Presence of continuous physical micro-tremors verifies active organic lung recording."
                    }
                  </p>
                </div>
              </div>

              {analysis.voice_clone_indicators && analysis.voice_clone_indicators.length > 0 && (
                <div className="space-y-2.5">
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Spectral Signal Triggers:</span>
                  <div className="flex flex-wrap gap-2">
                    {analysis.voice_clone_indicators.map((indicator, idx) => (
                      <span key={idx} className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#1A1A2E] text-red-400 border border-red-500/20 rounded-lg text-xs font-mono">
                        <AlertCircle className="w-3.5 h-3.5" />
                        <span>{indicator}</span>
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ANALYSIS TEXTS */}
          <div className="glass-card rounded-2xl p-6 sm:p-8 space-y-4 border-l-4 border-l-[#1A73E8] bg-[#0A1628] border-y border-r border-slate-800 shadow-xl" id="forensic-verdict-details">
            <h3 className="flex items-center space-x-2 font-display text-lg font-extrabold text-white">
              <FileCheck className="h-5 w-5 text-[#1A73E8]" />
              <span>Diagnostic Forensic Log</span>
            </h3>
            
            <p className="text-sm text-slate-300 leading-relaxed text-justify whitespace-pre-line">
              {analysis.explanation}
            </p>
          </div>

          {/* SUSPICIOUS SIGNALS */}
          <div className="glass-card rounded-2xl p-6 sm:p-8 space-y-4 bg-[#0A1628] border border-slate-800 shadow-xl">
            <h3 className="flex items-center space-x-2 font-display text-lg font-extrabold text-white">
              <Binary className="h-5 w-5 text-[#1A73E8]" />
              <span>Anomalous Signal Detections</span>
            </h3>

            <div className="flex flex-wrap gap-2">
              {analysis.suspicious_regions.map((signal, idx) => (
                <span 
                  key={idx}
                  className={`inline-flex items-center gap-2 rounded-lg px-3.5 py-2 text-xs font-bold border ${badgeColor}`}
                >
                  <span className={`h-2 w-2 rounded-full ${isAi ? "bg-[#FF1744]" : "bg-[#00C853]"}`} />
                  <span>{signal}</span>
                </span>
              ))}
            </div>
          </div>

          {/* RECIPIENT REPORT SHARING (Priority 11) */}
          <div className="glass-card rounded-2xl p-6 bg-[#0A1628] border border-slate-800 shadow-xl space-y-4" id="report-share-form-box">
            <h3 className="font-display text-base font-extrabold text-white flex items-center gap-2">
              <Share2 className="w-5 h-5 text-[#1A73E8]" />
              <span>Distribute Forensic Certificate</span>
            </h3>
            <p className="text-xs text-slate-400">Share verification and PDF report via Email or WhatsApp directly.</p>

            {shareStatus && (
              <div className={`p-3.5 rounded-lg text-xs flex items-center gap-2 ${shareStatus.success ? "bg-emerald-500/10 border border-emerald-500/20 text-emerald-400" : "bg-red-500/10 border border-red-500/20 text-red-400"}`} id="share-feedback">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{shareStatus.message}</span>
              </div>
            )}

            <form onSubmit={handleShareSubmit} className="flex flex-col sm:flex-row gap-3" id="share-form">
              <div className="flex gap-1.5 p-1 bg-slate-900 border border-slate-800 rounded-lg" id="share-method-group">
                <button
                  id="share-email-tab"
                  type="button"
                  className={`px-3 py-1.5 rounded-md text-xs font-semibold ${shareMethod === "email" ? "bg-[#1A73E8] text-white" : "text-slate-400"}`}
                  onClick={() => setShareMethod("email")}
                >
                  Email
                </button>
                <button
                  id="share-whatsapp-tab"
                  type="button"
                  className={`px-3 py-1.5 rounded-md text-xs font-semibold ${shareMethod === "whatsapp" ? "bg-[#1A73E8] text-white" : "text-slate-400"}`}
                  onClick={() => setShareMethod("whatsapp")}
                >
                  WhatsApp
                </button>
              </div>

              <input
                id="share-recipient-input"
                type={shareMethod === "email" ? "email" : "text"}
                required
                placeholder={shareMethod === "email" ? "forensic-auditor@firm.com" : "+1 (555) 019-2834"}
                className="flex-grow bg-slate-950 border border-slate-800 rounded-lg px-3.5 py-2 text-slate-200 text-xs placeholder-slate-600 focus:outline-none focus:border-[#1A73E8]"
                value={shareRecipient}
                onChange={(e) => setShareRecipient(e.target.value)}
              />

              <button
                id="share-submit-btn"
                type="submit"
                disabled={sharingLoading}
                className="bg-slate-900 hover:bg-slate-800 border border-slate-800 text-white font-bold py-2 px-4 rounded-lg text-xs transition-colors flex items-center justify-center gap-1.5 disabled:opacity-50"
              >
                {sharingLoading ? <Loader className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5 text-[#1A73E8]" />}
                <span>Send</span>
              </button>
            </form>
          </div>

          {/* REPORT CORRECTION / FEEDBACK WIDGET (Priority 16) */}
          <div className="glass-card rounded-2xl p-6 bg-[#0A1628] border border-slate-800 shadow-xl space-y-4" id="ai-model-feedback-box">
            <h3 className="font-display text-base font-extrabold text-white flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-[#1A73E8]" />
              <span>AI Core Model Feedback</span>
            </h3>
            <p className="text-xs text-slate-400">Did our network classify this correctly? Help improve TruthLens neural models.</p>

            {feedbackStatus && (
              <div className="p-3.5 rounded-lg bg-[#1A73E8]/10 border border-[#1A73E8]/20 text-slate-300 text-xs flex items-center gap-2" id="feedback-banner">
                <ShieldCheck className="w-4.5 h-4.5 text-[#1A73E8] shrink-0" />
                <span>{feedbackStatus}</span>
              </div>
            )}

            <form onSubmit={handleFeedbackSubmit} className="space-y-3" id="feedback-form">
              <div>
                <label className="block text-[10.5px] font-bold text-slate-400 uppercase tracking-wider mb-1">Your Correction Verdict:</label>
                <select
                  id="feedback-correction-select"
                  required
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-300 text-xs focus:outline-none focus:border-[#1A73E8]"
                  value={feedbackCorrection}
                  onChange={(e) => setFeedbackCorrection(e.target.value)}
                >
                  <option value="">-- Choose correct classification --</option>
                  <option value="HUMAN-GENERATED">It is definitely Human-Generated (Authentic)</option>
                  <option value="AI-GENERATED">It is definitely AI-Generated (Deepfake)</option>
                </select>
              </div>

              <div>
                <label className="block text-[10.5px] font-bold text-slate-400 uppercase tracking-wider mb-1">Auditor Comments (Optional):</label>
                <textarea
                  id="feedback-comment-textarea"
                  placeholder="Tell us what visual or spectral patterns the model missed..."
                  rows={2}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-300 text-xs focus:outline-none focus:border-[#1A73E8]"
                  value={feedbackComment}
                  onChange={(e) => setFeedbackComment(e.target.value)}
                />
              </div>

              <button
                id="feedback-submit-btn"
                type="submit"
                disabled={feedbackLoading}
                className="w-full bg-[#1A73E8]/10 border border-[#1A73E8]/20 hover:bg-[#1A73E8]/20 text-white font-bold py-2 rounded-lg text-xs transition-colors flex items-center justify-center gap-1.5 disabled:opacity-50"
              >
                {feedbackLoading ? <Loader className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5 text-[#1A73E8]" />}
                <span>Submit Feedback</span>
              </button>
            </form>
          </div>

          {/* ACTION BUTTONS */}
          <div className="flex flex-col sm:flex-row gap-4 pt-4">
            <a
              id="download-pdf-report-btn"
              href={getReportDownloadUrl(analysis.id)}
              className="flex-grow flex items-center justify-center space-x-2 rounded-xl bg-gradient-to-r from-[#1A73E8] to-[#1557B0] hover:from-[#1b7dfb] hover:to-[#175ec2] px-6 py-4 font-display text-sm font-bold text-white shadow-lg shadow-blue-500/30 transition-all hover:scale-[1.01] active:scale-95 blue-glow"
            >
              <FileText className="h-5 w-5" />
              <span>Download Signed PDF</span>
            </a>

            <Link
              id="analyze-another-media-btn"
              to="/detect"
              className="flex items-center justify-center space-x-2 rounded-xl border border-slate-800 bg-transparent hover:bg-white/5 px-6 py-4 font-display text-sm font-bold text-white transition-colors"
            >
              <RotateCcw className="h-5 w-5 text-slate-400" />
              <span>Analyze Another</span>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
