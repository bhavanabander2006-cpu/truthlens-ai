import React from "react";
import { Link } from "react-router-dom";
import { 
  FileImage, 
  FileAudio, 
  FileVideo, 
  ShieldCheck, 
  Binary, 
  Fingerprint, 
  Eye, 
  Cpu, 
  ArrowRight,
  Sparkles,
  Search,
  BookOpen,
  Download,
  Zap
} from "lucide-react";

export default function LandingPage() {
  return (
    <div className="space-y-24 pb-20 bg-[#050A1A]">
      {/* Hero Section */}
      <section className="relative overflow-hidden px-4 pt-16 pb-20 sm:px-6 lg:px-8 text-center lg:pt-24">
        {/* Animated blue particle grid in background & subtle blue glow */}
        <div className="absolute inset-0 -z-10 bg-[linear-gradient(to_right,rgba(26,115,232,0.05)_1px,transparent_1px),linear-gradient(to_bottom,rgba(26,115,232,0.05)_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)]" />
        <div className="absolute top-0 left-1/2 -z-10 h-[400px] w-[800px] -translate-x-1/2 rounded-full bg-gradient-to-b from-[#1A73E8]/10 via-[#4285F4]/5 to-transparent blur-[120px]" />

        <div className="mx-auto max-w-4xl space-y-6">
          <div className="inline-flex items-center space-x-2 rounded-full border border-[#1A3A6B] bg-[#1A73E8]/10 px-4.5 py-1.5 text-xs font-semibold tracking-wider text-[#4285F4] uppercase">
            <Sparkles className="h-3.5 w-3.5 animate-pulse text-[#1A73E8]" />
            <span>Forensic Grade Multi-Spectral Scanning</span>
          </div>

          <h2 className="font-display text-4xl font-extrabold tracking-tight text-white sm:text-6xl lg:text-7xl">
            Detect. Explain.<br />
            <span className="bg-gradient-to-r from-white via-[#E8F0FE] to-[#1A73E8] bg-clip-text text-transparent drop-shadow-[0_0_15px_rgba(26,115,232,0.3)]">
              Trust the Origin.
            </span>
          </h2>

          <p className="mx-auto max-w-2xl text-base text-[#A8C0E8] sm:text-lg leading-relaxed">
            TruthLens AI uses advanced artificial intelligence to determine whether 
            any image, audio, or video was created by AI or captured by a human.
          </p>

          <div className="mt-10 flex flex-col items-center justify-center space-y-4 sm:flex-row sm:space-y-0 sm:space-x-4">
            <Link
              id="start-detection-btn"
              to="/detect"
              className="btn-primary group flex w-full items-center justify-center space-x-2 rounded-xl px-8 py-4 font-display text-base font-bold transition-all sm:w-auto"
            >
              <span>Start Detection</span>
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
            
            <Link
              id="view-dashboard-btn"
              to="/dashboard"
              className="flex w-full items-center justify-center space-x-2 rounded-xl border border-[#1A73E8] bg-transparent px-8 py-4 font-display text-base font-semibold text-white transition-all hover:bg-[#1A73E8]/10 sm:w-auto"
            >
              <span>View Dashboard</span>
            </Link>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="bg-[#0A1628] py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 space-y-12">
          <div className="text-center space-y-2">
            <h3 className="font-display text-2xl font-extrabold tracking-tight text-white sm:text-3xl">
              How It Works
            </h3>
            <p className="text-sm text-[#A8C0E8] max-w-md mx-auto">
              Analyze any file in three precise steps. Our network extracts deep signal irregularities immediately.
            </p>
          </div>

          <div className="grid gap-8 md:grid-cols-3 relative">
            {/* Step 1 */}
            <div className="glass-card rounded-2xl p-8 relative flex flex-col items-center text-center space-y-4">
              <span className="absolute top-4 left-4 font-mono text-xs font-bold text-[#4285F4] bg-[#1A73E8]/10 px-2.5 py-1 rounded-full border border-[#1A3A6B]">
                01
              </span>
              <div className="flex h-14 w-14 items-center justify-center rounded-full bg-[#1A73E8] text-white blue-glow">
                <FileImage className="h-6 w-6" />
              </div>
              <h4 className="font-display font-bold text-white text-base">Upload Media</h4>
              <p className="text-xs text-[#A8C0E8] leading-relaxed">
                Drag and drop your file (image, audio, or video) up to 50MB directly into our forensic dropzone.
              </p>
            </div>

            {/* Connecting Arrow 1 */}
            <div className="hidden md:flex absolute top-1/2 left-[30%] -translate-y-1/2 z-10 text-[#1A73E8]">
              <ArrowRight className="h-6 w-6 animate-pulse" />
            </div>

            {/* Step 2 */}
            <div className="glass-card rounded-2xl p-8 relative flex flex-col items-center text-center space-y-4">
              <span className="absolute top-4 left-4 font-mono text-xs font-bold text-[#4285F4] bg-[#1A73E8]/10 px-2.5 py-1 rounded-full border border-[#1A3A6B]">
                02
              </span>
              <div className="flex h-14 w-14 items-center justify-center rounded-full bg-[#1A73E8] text-white blue-glow">
                <Search className="h-6 w-6" />
              </div>
              <h4 className="font-display font-bold text-white text-base">AI Analysis</h4>
              <p className="text-xs text-[#A8C0E8] leading-relaxed">
                Our analyzer runs discrete Fourier, ELA, EXIF metadata validation and pixel/temporal audits.
              </p>
            </div>

            {/* Connecting Arrow 2 */}
            <div className="hidden md:flex absolute top-1/2 left-[64%] -translate-y-1/2 z-10 text-[#1A73E8]">
              <ArrowRight className="h-6 w-6 animate-pulse" />
            </div>

            {/* Step 3 */}
            <div className="glass-card rounded-2xl p-8 relative flex flex-col items-center text-center space-y-4">
              <span className="absolute top-4 left-4 font-mono text-xs font-bold text-[#4285F4] bg-[#1A73E8]/10 px-2.5 py-1 rounded-full border border-[#1A3A6B]">
                03
              </span>
              <div className="flex h-14 w-14 items-center justify-center rounded-full bg-[#1A73E8] text-white blue-glow">
                <ShieldCheck className="h-6 w-6" />
              </div>
              <h4 className="font-display font-bold text-white text-base">Get Verdict</h4>
              <p className="text-xs text-[#A8C0E8] leading-relaxed">
                Review a transparent verdict of AI-Generated or Human-Generated, accompanied by a downloadable PDF.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Why TruthLens AI (Features Section) */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="text-center space-y-2">
          <h3 className="font-display text-2xl font-extrabold tracking-tight text-white sm:text-3xl">
            Why TruthLens AI
          </h3>
          <p className="text-sm text-[#A8C0E8] max-w-md mx-auto">
            Our platform provides unmatched granularity and verification accuracy across multiple media pipelines.
          </p>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {/* Feature 1 */}
          <div className="glass-card rounded-2xl p-6 space-y-4 card-transition border border-[#1A3A6B]">
            <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[#1A73E8] text-white">
              <Cpu className="h-5.5 w-5.5" />
            </div>
            <h4 className="font-display font-bold text-white text-base">Multi-Modal Detection</h4>
            <p className="text-xs text-[#A8C0E8] leading-relaxed">
              Consolidated scanning pipeline support for images, voice captures, and videos inside a single uniform forensic dashboard.
            </p>
          </div>

          {/* Feature 2 */}
          <div className="glass-card rounded-2xl p-6 space-y-4 card-transition border border-[#1A3A6B]">
            <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[#1A73E8] text-white">
              <Fingerprint className="h-5.5 w-5.5" />
            </div>
            <h4 className="font-display font-bold text-white text-base">AI vs Human Verdict</h4>
            <p className="text-xs text-[#A8C0E8] leading-relaxed">
              Deterministic classifications pointing clearly to either genuine human capture or synthetic neural models.
            </p>
          </div>

          {/* Feature 3 */}
          <div className="glass-card rounded-2xl p-6 space-y-4 card-transition border border-[#1A3A6B]">
            <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[#1A73E8] text-white">
              <Binary className="h-5.5 w-5.5" />
            </div>
            <h4 className="font-display font-bold text-white text-base">Confidence Heuristics</h4>
            <p className="text-xs text-[#A8C0E8] leading-relaxed">
              Highly calibrated risk percentage detailing the calculated strength of the detection hypothesis with complete precision.
            </p>
          </div>

          {/* Feature 4 */}
          <div className="glass-card rounded-2xl p-6 space-y-4 card-transition border border-[#1A3A6B]">
            <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[#1A73E8] text-white">
              <BookOpen className="h-5.5 w-5.5" />
            </div>
            <h4 className="font-display font-bold text-white text-base">Explainable Results</h4>
            <p className="text-xs text-[#A8C0E8] leading-relaxed">
              No black-box mystery. Access clear forensic logs explaining the specific mechanical reasons behind the decision.
            </p>
          </div>

          {/* Feature 5 */}
          <div className="glass-card rounded-2xl p-6 space-y-4 card-transition border border-[#1A3A6B]">
            <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[#1A73E8] text-white">
              <Download className="h-5.5 w-5.5" />
            </div>
            <h4 className="font-display font-bold text-white text-base">Forensic PDF Reports</h4>
            <p className="text-xs text-[#A8C0E8] leading-relaxed">
              Download professionally structured and signed forensic assessment PDFs suitable for legal audits or newsroom reviews.
            </p>
          </div>

          {/* Feature 6 */}
          <div className="glass-card rounded-2xl p-6 space-y-4 card-transition border border-[#1A3A6B]">
            <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[#1A73E8] text-white">
              <Zap className="h-5.5 w-5.5" />
            </div>
            <h4 className="font-display font-bold text-white text-base">Fast & Secure</h4>
            <p className="text-xs text-[#A8C0E8] leading-relaxed">
              Optimized parallel processing triggers instantaneous feedback. Uploaded files remain confidential and run securely.
            </p>
          </div>
        </div>
      </section>

      {/* Supported Formats Section */}
      <section className="bg-[#050A1A] py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 space-y-12">
          <div className="text-center space-y-2">
            <h3 className="font-display text-2xl font-extrabold tracking-tight text-white sm:text-3xl">
              Supported Formats
            </h3>
            <p className="text-sm text-[#A8C0E8] max-w-md mx-auto">
              High-fidelity analysis supports all industry standard high-definition file extensions.
            </p>
          </div>

          <div className="grid gap-8 sm:grid-cols-3">
            {/* Images column */}
            <div className="glass-card rounded-2xl p-8 flex flex-col items-center text-center space-y-4 border border-[#1A3A6B]">
              <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-[#1A73E8]/10 text-[#1A73E8]">
                <FileImage className="h-6 w-6" />
              </div>
              <h4 className="font-display font-extrabold text-white text-base">Images</h4>
              <p className="text-xs text-[#A8C0E8]">JPG, PNG, WEBP</p>
              <span className="text-[10px] font-mono font-semibold uppercase tracking-wider text-[#A8C0E8] bg-[#0A1628] border border-[#1A3A6B] px-2.5 py-1 rounded-md">
                Spectral Scan
              </span>
            </div>

            {/* Audio column */}
            <div className="glass-card rounded-2xl p-8 flex flex-col items-center text-center space-y-4 border border-[#1A3A6B]">
              <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-[#1A73E8]/10 text-[#1A73E8]">
                <FileAudio className="h-6 w-6" />
              </div>
              <h4 className="font-display font-extrabold text-white text-base">Audio</h4>
              <p className="text-xs text-[#A8C0E8]">MP3, WAV, M4A, OGG</p>
              <span className="text-[10px] font-mono font-semibold uppercase tracking-wider text-[#A8C0E8] bg-[#0A1628] border border-[#1A3A6B] px-2.5 py-1 rounded-md">
                Pitch Track
              </span>
            </div>

            {/* Video column */}
            <div className="glass-card rounded-2xl p-8 flex flex-col items-center text-center space-y-4 border border-[#1A3A6B]">
              <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-[#1A73E8]/10 text-[#1A73E8]">
                <FileVideo className="h-6 w-6" />
              </div>
              <h4 className="font-display font-extrabold text-white text-base">Videos</h4>
              <p className="text-xs text-[#A8C0E8]">MP4, MOV, AVI, WEBM</p>
              <span className="text-[10px] font-mono font-semibold uppercase tracking-wider text-[#A8C0E8] bg-[#0A1628] border border-[#1A3A6B] px-2.5 py-1 rounded-md">
                Deepfake Track
              </span>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
