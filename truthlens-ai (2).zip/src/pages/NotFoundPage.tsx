import React from "react";
import { Link } from "react-router-dom";
import { ShieldAlert, Home } from "lucide-react";

export default function NotFoundPage() {
  return (
    <div className="flex min-h-[60vh] flex-col items-center justify-center px-4 py-16 text-center space-y-6 bg-[#050A1A]">
      <div className="relative flex h-24 w-24 items-center justify-center rounded-full bg-[#1A73E8]/10 border border-[#1A3A6B] text-[#1A73E8]">
        <ShieldAlert className="h-12 w-12 animate-pulse" />
        <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-white text-[10px] font-bold text-[#1A73E8]">
          404
        </span>
      </div>

      <div className="space-y-2 max-w-md">
        <h2 className="font-display text-5xl font-black tracking-tight text-[#1A73E8] sm:text-6xl">
          404 <span className="text-white">ERROR</span>
        </h2>
        <h3 className="font-display text-xl font-bold text-white">
          Page Not Found
        </h3>
        <p className="text-sm text-[#A8C0E8]">
          The forensic node you are looking for does not exist or has been moved outside our verification parameters.
        </p>
      </div>

      <Link
        to="/"
        className="flex items-center space-x-2 rounded-xl bg-[#1A73E8] px-6 py-3.5 font-display text-sm font-bold text-white shadow-lg shadow-blue-500/30 transition-all hover:bg-[#0D47A1] active:scale-95 blue-glow"
      >
        <Home className="h-4 w-4" />
        <span>Return to Headquarters</span>
      </Link>
    </div>
  );
}
