import React, { useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { 
  UploadCloud, 
  FileImage, 
  FileAudio, 
  FileVideo, 
  AlertTriangle,
  ArrowRight,
  ShieldAlert,
  Loader,
  RefreshCw,
  X,
  Download,
  Sparkles,
  Check,
  Cpu,
  Activity,
  Play
} from "lucide-react";
import { detectImage, detectAudio, detectVideo } from "../services/api";
import { SAMPLE_PLAYGROUND } from "../data/benchmarks";

type TabId = "image" | "audio" | "video";

const ACTIVE_SCANNING_MESSAGES = [
  "Opening file stream and extracting binary buffer...",
  "Querying camera EXIF metadata headers...",
  "Applying discrete Error Level JPEG compression (ELA)...",
  "Computing spatial noise entropy and surface smoothness...",
  "Performing Fast Fourier Transform (FFT) on coordinate matrix...",
  "Detecting face boundary structures and lighting vectors...",
  "Synthesizing forensic diagnostic verdict..."
];


export default function DetectPage() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<TabId>("image");
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [scanStepIndex, setScanStepIndex] = useState(0);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [showDownloads, setShowDownloads] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const loadSampleFile = async (fileName: string, tab: TabId) => {
    try {
      setErrorMessage(null);
      const response = await fetch(`/samples/${fileName}`);
      if (!response.ok) {
        throw new Error("Sample file not found on the server");
      }
      const blob = await response.blob();
      
      let mime = blob.type;
      if (!mime) {
        if (fileName.endsWith(".png")) mime = "image/png";
        else if (fileName.endsWith(".jpg") || fileName.endsWith(".jpeg")) mime = "image/jpeg";
        else if (fileName.endsWith(".mp3")) mime = "audio/mpeg";
        else if (fileName.endsWith(".wav")) mime = "audio/wav";
        else if (fileName.endsWith(".mp4")) mime = "video/mp4";
      }

      const loadedFile = new File([blob], fileName, { type: mime });
      setActiveTab(tab);
      setFile(loadedFile);
      
      if (previewUrl) {
        URL.revokeObjectURL(previewUrl);
      }
      setPreviewUrl(URL.createObjectURL(loadedFile));
    } catch (error) {
      console.error("Failed to load sample file", error);
      setErrorMessage("Failed to load the sample file from the server.");
    }
  };


  const getAcceptedFormats = () => {
    switch (activeTab) {
      case "image": return "image/jpeg, image/png, image/webp";
      case "audio": return "audio/mpeg, audio/wav, audio/x-wav, audio/mp3, audio/ogg, audio/aac, audio/m4a";
      case "video": return "video/mp4, video/quicktime, video/x-msvideo, video/webm, video/x-matroska";
    }
  };

  const getTabLabel = () => {
    switch (activeTab) {
      case "image": return "Image File (JPG, PNG, WEBP)";
      case "audio": return "Audio Voice Track (MP3, WAV)";
      case "video": return "Video Stream (MP4, MOV)";
    }
  };

  const getFormatsText = () => {
    switch (activeTab) {
      case "image": return "JPG, PNG, WEBP";
      case "audio": return "MP3, WAV, M4A, OGG";
      case "video": return "MP4, MOV, AVI, WEBM";
    }
  };

  const handleTabChange = (tab: TabId) => {
    if (isScanning) return;
    setActiveTab(tab);
    handleClear();
  };

  const handleFileSelection = (selectedFile: File, shouldAutoAnalyze: boolean = false) => {
    setErrorMessage(null);
    if (selectedFile.size > 50 * 1024 * 1024) {
      setErrorMessage("File too large. Maximum size is 50MB");
      return;
    }

    // Automatically detect file type
    const mime = selectedFile.type.toLowerCase();
    const name = selectedFile.name.toLowerCase();
    
    let detectedTab: TabId | null = null;
    if (mime.startsWith("image/") || /\.(jpg|jpeg|png|webp)$/i.test(name)) {
      detectedTab = "image";
    } else if (mime.startsWith("audio/") || /\.(mp3|wav|ogg|aac|m4a)$/i.test(name)) {
      detectedTab = "audio";
    } else if (mime.startsWith("video/") || /\.(mp4|mov|avi|mkv|webm)$/i.test(name)) {
      detectedTab = "video";
    }

    if (!detectedTab) {
      setErrorMessage("Unsupported file type. Please upload an image, audio, or video file.");
      return;
    }
    
    setActiveTab(detectedTab);
    setFile(selectedFile);
    
    // Create preview
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
    }
    const newPreviewUrl = URL.createObjectURL(selectedFile);
    setPreviewUrl(newPreviewUrl);

    if (shouldAutoAnalyze) {
      triggerAnalysis(selectedFile, detectedTab);
    }
  };

  const handleFileChange = (selectedFile: File) => {
    handleFileSelection(selectedFile, false);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    if (isScanning) return;
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (isScanning) return;
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileSelection(e.dataTransfer.files[0], false);
    }
  };

  const handleClear = () => {
    setFile(null);
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
      setPreviewUrl(null);
    }
    setErrorMessage(null);
  };

  const triggerAnalysis = async (fileToAnalyze?: File, tabToAnalyze?: TabId) => {
    const targetFile = fileToAnalyze || file;
    const targetTab = tabToAnalyze || activeTab;
    if (!targetFile) return;

    setIsScanning(true);
    setScanProgress(5);
    setScanStepIndex(0);

    // Animate loading step texts in background while fetching
    const progressInterval = setInterval(() => {
      setScanProgress((prev) => {
        if (prev >= 92) return prev; // Hold until done
        return prev + Math.floor(Math.random() * 5) + 2;
      });
    }, 350);

    const stepInterval = setInterval(() => {
      setScanStepIndex((prev) => {
        if (prev >= ACTIVE_SCANNING_MESSAGES.length - 1) return prev;
        return prev + 1;
      });
    }, 1100);

    try {
      let result;
      if (targetTab === "image") {
        result = await detectImage(targetFile);
      } else if (targetTab === "audio") {
        result = await detectAudio(targetFile);
      } else {
        result = await detectVideo(targetFile);
      }

      clearInterval(progressInterval);
      clearInterval(stepInterval);
      setScanProgress(100);

      // Brief pause for visual completion feedback
      setTimeout(() => {
        setIsScanning(false);
        navigate(`/results/${result.id}`);
      }, 400);

    } catch (err: any) {
      clearInterval(progressInterval);
      clearInterval(stepInterval);
      setIsScanning(false);
      setErrorMessage("Unable to connect to server. Please try again.");
    }
  };

  return (
    <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6 lg:px-8 space-y-8 bg-[#050A1A]">
      {/* Page Title */}
      <div className="text-center space-y-2">
        <h2 className="font-display text-3xl font-extrabold tracking-tight text-white sm:text-4xl">
          Upload Media for Analysis
        </h2>
        <p className="text-sm text-[#A8C0E8]">
          Upload any image, audio, or video to detect if it is AI-Generated or Human-Generated.
        </p>
      </div>

      {/* Tabs Selector */}
      <div className="grid grid-cols-3 gap-2 rounded-xl bg-[#0A1628] p-1.5 border border-[#1A3A6B]">
        {(["image", "audio", "video"] as TabId[]).map((tab) => (
          <button
            key={tab}
            onClick={() => handleTabChange(tab)}
            disabled={isScanning}
            className={`rounded-lg py-3 text-xs font-bold uppercase tracking-wider transition-all duration-200 ${
              activeTab === tab
                ? "bg-[#1A73E8] text-white shadow-md shadow-blue-500/30 blue-glow"
                : "text-[#6B8CAE] hover:text-white hover:bg-white/5 disabled:opacity-50"
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Main Container */}
      <div className="space-y-6">
        {!isScanning ? (
          <>
            {/* Upload Area */}
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => !file && fileInputRef.current?.click()}
              className={`relative flex min-h-[300px] flex-col items-center justify-center rounded-2xl border-2 border-dashed p-8 text-center transition-all ${
                isDragging
                  ? "border-[#1A73E8] bg-[#0D1F3C] shadow-lg shadow-blue-900/20"
                  : file
                  ? "border-[#1A3A6B] bg-[#0A1628] cursor-default"
                  : "border-[#1A3A6B] bg-[#0A1628]/40 hover:border-[#1A73E8] hover:bg-[#0D1F3C] cursor-pointer"
              }`}
            >
              <input
                type="file"
                ref={fileInputRef}
                onChange={(e) => e.target.files && handleFileChange(e.target.files[0])}
                className="hidden"
                accept="image/*,audio/*,video/*"
              />

              {!file ? (
                <div className="space-y-4">
                  <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-[#1A73E8]/10 border border-[#1A3A6B] text-[#1A73E8]">
                    <UploadCloud className="h-7 w-7" />
                  </div>
                  <div className="space-y-1">
                    <p className="font-display text-base font-semibold text-white">
                      Drag & drop your file here or <span className="text-[#1A73E8] hover:underline">browse</span>
                    </p>
                    <p className="text-xs text-[#A8C0E8]">
                      Supported extensions: {getTabLabel()}
                    </p>
                    <p className="text-[10px] text-[#6B8CAE] font-mono">
                      MAXIMUM FILE SIZE: 50MB
                    </p>
                  </div>
                </div>
              ) : (
                <div className="w-full space-y-6">
                  {/* Selected Preview State */}
                  <div className="flex flex-col items-center justify-center space-y-4 md:flex-row md:space-y-0 md:space-x-6 text-left max-w-xl mx-auto p-4 rounded-xl border border-[#1A3A6B] bg-[#0A1628]">
                    {/* Visual Preview Frame */}
                    <div className="h-32 w-32 shrink-0 overflow-hidden rounded-xl bg-[#050A1A] border border-[#1A3A6B] flex items-center justify-center">
                      {activeTab === "image" && previewUrl && (
                        <img 
                          src={previewUrl} 
                          alt="Forensic capture preview" 
                          className="h-full w-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      )}
                      {activeTab === "image" && !previewUrl && <FileImage className="h-10 w-10 text-[#1A73E8]" />}
                      {activeTab === "audio" && <FileAudio className="h-10 w-10 text-[#1A73E8]" />}
                      {activeTab === "video" && <FileVideo className="h-10 w-10 text-[#1A73E8]" />}
                    </div>

                    {/* Meta info */}
                    <div className="flex-grow space-y-2 text-center md:text-left min-w-0">
                      <p className="truncate font-display font-bold text-white text-base">
                        {file.name}
                      </p>
                      <p className="text-xs text-[#A8C0E8] font-mono">
                        SIZE: <span>{(file.size / (1024 * 1024)).toFixed(2)} MB</span>
                        <span className="mx-2">•</span>
                        TYPE: <span className="uppercase">{activeTab}</span>
                      </p>

                      <button
                        type="button"
                        onClick={handleClear}
                        className="inline-flex items-center space-x-1 rounded-lg border border-[#1A3A6B] bg-white/5 px-3 py-1.5 text-xs font-semibold text-white hover:bg-white/10"
                      >
                        <X className="h-3.5 w-3.5 text-[#6B8CAE]" />
                        <span>Remove file</span>
                      </button>
                    </div>
                  </div>

                  {/* NATIVE PLAYER PLAYGROUND PREVIEW */}
                  {activeTab === "audio" && previewUrl && (
                    <div className="max-w-md mx-auto pt-2">
                      <audio src={previewUrl} controls className="w-full h-10 rounded-lg" />
                    </div>
                  )}

                  {activeTab === "video" && previewUrl && (
                    <div className="max-w-md mx-auto aspect-video rounded-xl overflow-hidden border border-[#1A3A6B] bg-[#050A1A]">
                      <video src={previewUrl} controls className="w-full h-full" />
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Error Message Box */}
            {errorMessage && (
              <div className="flex items-start space-x-3 rounded-xl border border-rose-950/40 bg-rose-950/20 p-4 text-xs text-rose-400">
                <AlertTriangle className="h-5 w-5 shrink-0 text-[#FF1744]" />
                <div className="flex-grow space-y-1">
                  <h4 className="font-bold uppercase tracking-wider text-white">Forensic Signal Error</h4>
                  <p className="leading-relaxed text-slate-300">{errorMessage}</p>
                  <button
                    onClick={handleClear}
                    className="mt-2 text-[11px] font-bold text-[#FF1744] hover:underline flex items-center space-x-1"
                  >
                    <RefreshCw className="h-3 w-3" />
                    <span>Clear & Try Again</span>
                  </button>
                </div>
              </div>
            )}

            {/* Action Trigger Button */}
            {file && (
              <button
                type="button"
                onClick={triggerAnalysis}
                className="flex w-full items-center justify-center space-x-2.5 rounded-xl bg-gradient-to-r from-[#1A73E8] to-[#0D47A1] px-6 py-4 font-display font-bold text-white shadow-lg shadow-blue-500/30 transition-all hover:scale-[1.01] hover:shadow-blue-500/40 active:scale-95 blue-glow"
              >
                <span>Analyze Now</span>
                <ArrowRight className="h-5 w-5" />
              </button>
            )}
          </>
        ) : (
          /* SCANNING ACTIVE SCREEN OVERLAY - Matches the design requirements */
          <div className="glass-card rounded-2xl p-8 sm:p-12 text-center space-y-8 bg-[#050A1A]/95">
            <div className="relative mx-auto flex h-24 w-24 items-center justify-center rounded-full bg-[#1A73E8]/10 border border-[#1A3A6B]">
              <Loader className="h-12 w-12 animate-spin text-[#1A73E8]" />
              <ShieldAlert className="absolute inset-0 m-auto h-6 w-6 text-white animate-pulse" />
            </div>

            <div className="space-y-2">
              <h3 className="font-display text-xl font-bold tracking-tight text-white uppercase tracking-wider">
                TruthLens AI is analyzing your media...
              </h3>
              <p className="text-xs text-[#A8C0E8] font-medium">
                This may take a few seconds
              </p>
              {/* Dynamic analysis steps log */}
              <p className="h-5 font-mono text-xs text-[#1A73E8] tracking-wide animate-pulse">
                {ACTIVE_SCANNING_MESSAGES[scanStepIndex]}
              </p>
            </div>

            {/* Progress metrics */}
            <div className="space-y-2 max-w-md mx-auto">
              <div className="flex justify-between font-mono text-[10px] text-[#6B8CAE]">
                <span>COMPILING SPECTRAL CODES</span>
                <span>{scanProgress}%</span>
              </div>
              <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-[#1A73E8] to-[#0D47A1] transition-all duration-300"
                  style={{ width: `${scanProgress}%` }}
                />
              </div>
            </div>
          </div>
        )}
      </div>

    </div>
  );
}

