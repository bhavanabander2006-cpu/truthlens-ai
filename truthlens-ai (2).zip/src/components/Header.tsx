import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { ShieldCheck, Menu, X, Database, UploadCloud, Home, LogOut, LogIn, User } from "lucide-react";
import { useAuth } from "../services/AuthContext";

export default function Header() {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();
  const { user, logout, isAuthenticated } = useAuth();

  const isActive = (path: string) => {
    if (path === "/") {
      return location.pathname === "/";
    }
    return location.pathname.startsWith(path);
  };

  const navItems = [
    { name: "Home", path: "/", icon: Home },
    { name: "Detect", path: "/detect", icon: UploadCloud },
    { name: "Dashboard", path: "/dashboard", icon: Database },
  ];

  return (
    <header className="sticky top-0 z-50 border-b border-[#1A3A6B] bg-[#050A1A]/80 backdrop-blur-md">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-20 items-center justify-between">
          {/* Brand Logo */}
          <Link to="/" className="flex items-center space-x-3 transition-transform active:scale-95">
            <div className="relative flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-tr from-[#1A73E8] to-[#4285F4] shadow-lg shadow-blue-500/30 blue-glow">
              <ShieldCheck className="h-6 w-6 text-white" />
              <span className="absolute -top-0.5 -right-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-white text-[9px] font-extrabold text-[#1A73E8]">
                SEC
              </span>
            </div>
            <div>
              <h1 className="font-display text-xl font-extrabold tracking-tight text-white sm:text-2xl drop-shadow-[0_0_8px_rgba(26,115,232,0.5)]">
                Truth<span className="text-[#1A73E8]">Lens</span>
                <span className="ml-1.5 rounded-md bg-[#1A73E8]/15 px-1.5 py-0.5 text-xs font-semibold tracking-wider text-[#4285F4]">
                  AI
                </span>
              </h1>
              <p className="text-[9px] font-bold tracking-widest text-[#A8C0E8] uppercase">
                Forensic Verification
              </p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const active = isActive(item.path);
              return (
                <Link
                  key={item.name}
                  to={item.path}
                  className={`flex items-center space-x-2 rounded-xl px-4 py-2.5 text-sm font-semibold tracking-wide transition-all ${
                    active
                      ? "bg-[#1A73E8] text-white shadow-md shadow-blue-500/30 blue-glow"
                      : "text-[#A8C0E8] hover:bg-white/5 hover:text-white"
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span>{item.name}</span>
                </Link>
              );
            })}

            {isAuthenticated ? (
              <div className="flex items-center space-x-3 ml-4 border-l border-slate-800 pl-4">
                <div className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-slate-300">
                  <User className="h-3.5 w-3.5 text-[#1A73E8]" />
                  <span className="font-medium max-w-[100px] truncate">{user?.name}</span>
                </div>
                <button
                  id="header-logout-btn"
                  onClick={logout}
                  className="flex items-center space-x-1 px-3 py-2 text-xs font-semibold text-red-400 hover:text-red-300 rounded-lg hover:bg-red-500/10 transition-all"
                >
                  <LogOut className="h-3.5 w-3.5" />
                  <span>Sign Out</span>
                </button>
              </div>
            ) : (
              <Link
                id="header-signin-link"
                to="/login"
                className="flex items-center space-x-1.5 ml-4 rounded-xl px-4 py-2.5 text-sm font-semibold tracking-wide bg-gradient-to-r from-[#1A73E8] to-[#1557B0] text-white hover:opacity-90 shadow-lg shadow-blue-900/20"
              >
                <LogIn className="h-4 w-4" />
                <span>Sign In</span>
              </Link>
            )}
          </nav>

          {/* Hamburger Menu Toggle */}
          <div className="flex md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              type="button"
              className="inline-flex items-center justify-center rounded-xl p-2.5 text-[#A8C0E8] hover:bg-white/5 hover:text-white focus:outline-none"
              aria-controls="mobile-menu"
              aria-expanded={isOpen}
            >
              <span className="sr-only">Open main menu</span>
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {isOpen && (
        <div className="md:hidden border-b border-[#1A3A6B] bg-[#050A1A] px-4 pt-2 pb-4 space-y-1.5" id="mobile-menu">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = isActive(item.path);
            return (
              <Link
                key={item.name}
                to={item.path}
                onClick={() => setIsOpen(false)}
                className={`flex items-center space-x-3 rounded-xl px-4 py-3 text-base font-semibold tracking-wide transition-all ${
                  active
                    ? "bg-[#1A73E8] text-white"
                    : "text-[#A8C0E8] hover:bg-white/5 hover:text-white"
                }`}
              >
                <Icon className="h-5 w-5" />
                <span>{item.name}</span>
              </Link>
            );
          })}

          <div className="pt-4 border-t border-slate-800 space-y-2">
            {isAuthenticated ? (
              <>
                <div className="flex items-center space-x-2 px-4 py-2 text-sm text-slate-300">
                  <User className="h-4 w-4 text-[#1A73E8]" />
                  <span>Logged in as <strong>{user?.name}</strong></span>
                </div>
                <button
                  id="mobile-logout-btn"
                  onClick={() => { logout(); setIsOpen(false); }}
                  className="flex w-full items-center space-x-3 rounded-xl px-4 py-3 text-base font-semibold text-red-400 hover:bg-red-500/10 transition-all"
                >
                  <LogOut className="h-5 w-5" />
                  <span>Sign Out</span>
                </button>
              </>
            ) : (
              <Link
                id="mobile-signin-btn"
                to="/login"
                onClick={() => setIsOpen(false)}
                className="flex w-full items-center justify-center space-x-2 rounded-xl px-4 py-3 text-base font-semibold bg-gradient-to-r from-[#1A73E8] to-[#1557B0] text-white shadow-md shadow-blue-500/30"
              >
                <LogIn className="h-5 w-5" />
                <span>Sign In</span>
              </Link>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
