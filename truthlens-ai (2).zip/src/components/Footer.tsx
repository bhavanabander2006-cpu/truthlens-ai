import React from "react";
import { ShieldCheck, Cpu, HardDrive } from "lucide-react";

export default function Footer() {
  return (
    <footer className="border-t border-[#1A3A6B] bg-[#030810] py-10 text-[#6B8CAE]">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col items-center justify-between space-y-6 md:flex-row md:space-y-0">
          <div className="flex items-center space-x-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#1A73E8]/10 border border-[#1A3A6B] text-[#1A73E8]">
              <ShieldCheck className="h-4.5 w-4.5" />
            </div>
            <div>
              <span className="font-display text-sm font-bold tracking-wider text-white">
                TruthLens AI
              </span>
              <p className="text-[10px] text-[#6B8CAE] uppercase tracking-widest font-mono">
                Detect. Explain. Trust.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-6 text-xs text-[#A8C0E8]">
            <div className="flex items-center space-x-1.5 font-mono">
              <Cpu className="h-3.5 w-3.5 text-[#1A73E8]" />
              <span>Multi-Modal Forensics</span>
            </div>
            <div className="flex items-center space-x-1.5 font-mono">
              <HardDrive className="h-3.5 w-3.5 text-[#2196F3]" />
              <span>Local Analytics Engine</span>
            </div>
          </div>

          <p className="text-xs text-[#6B8CAE] font-mono">
            &copy; 2026 TruthLens AI. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
