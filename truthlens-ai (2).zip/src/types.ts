export interface AnalysisRecord {
  id: string;
  user_id?: string;
  file_name: string;
  file_type: "image" | "audio" | "video";
  verdict: "AI-GENERATED" | "HUMAN-GENERATED";
  confidence_score: number;
  risk_level: "LOW" | "MEDIUM" | "HIGH";
  explanation: string;
  suspicious_regions: string[];
  timestamp: string;
  file_size?: string;
  watermark_detected?: boolean;
  watermark_type?: "C2PA" | "SynthID" | "none";
  watermark_details?: string;
  heatmap_image?: string; // base64 representation
  ela_image?: string; // base64 representation
  voice_emotion?: string;
  voice_emotion_confidence?: number;
  voice_clone_indicators?: string[];
  metadata?: {
    // Image scores
    exifScore?: number;
    elaScore?: number;
    noiseScore?: number;
    fftScore?: number;
    faceScore?: number;
    cameraMake?: string;
    cameraModel?: string;
    gpsCoordinates?: string;
    softwareUsed?: string;
    creationDate?: string;
    modificationDate?: string;
    fileHash?: string;
    compressionHistory?: string;
    
    // Audio scores
    spectrogramScore?: number;
    mfccScore?: number;
    pitchScore?: number;
    noiseScoreAudio?: number;
    breathScore?: number;

    // Video scores
    frameScore?: number;
    facialScore?: number;
    blinkScore?: number;
    temporalScore?: number;
    syncScore?: number;
  };
}

export interface User {
  id: string;
  email: string;
  password_hash?: string;
  name: string;
  auth_provider: "email" | "google";
  created_at: string;
}

export interface BatchJob {
  id: string;
  user_id: string;
  file_count: number;
  status: "processing" | "completed" | "failed";
  results: string[]; // List of analysis IDs
  created_at: string;
}

export interface FeedbackRecord {
  id: string;
  analysis_id: string;
  user_correction: "AI-GENERATED" | "HUMAN-GENERATED";
  comment: string;
  timestamp: string;
}

export type PageId = "landing" | "detect" | "results" | "dashboard" | "login" | "signup" | "analytics";

