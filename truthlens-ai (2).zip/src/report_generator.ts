import PDFDocument from "pdfkit";
import { AnalysisRecord } from "./types";

export function generateForensicPdf(analysis: AnalysisRecord): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument({
        margin: 50,
        size: "A4",
        bufferPages: true,
        info: {
          Title: `TruthLens Forensic Report - ${analysis.file_name}`,
          Author: "TruthLens AI",
          Subject: "Media Authenticity Analysis",
        },
      });

      const chunks: Buffer[] = [];
      doc.on("data", (chunk) => chunks.push(chunk));
      doc.on("end", () => resolve(Buffer.concat(chunks)));
      doc.on("error", (err) => reject(err));

      // --- COLOR PALETTE ---
      const navyDark = "#0F172A"; // Slate 900
      const grayLight = "#F8FAFC"; // Slate 50
      const grayBorder = "#E2E8F0"; // Slate 200
      const textMuted = "#64748B"; // Slate 500
      const textMain = "#334155"; // Slate 700
      const redVerdict = "#DC2626"; // Red 600
      const greenVerdict = "#16A34A"; // Green 600

      let y = 160;

      // Helper to handle page break safely
      const checkPageBreak = (neededHeight: number) => {
        // Page height is 841.89 (A4). With margin 50, maximum usable height is ~750.
        if (y + neededHeight > 750) {
          doc.addPage();
          y = 50;
        }
      };

      // --- HEADER BACKGROUND (only on first page) ---
      doc.rect(0, 0, 595.28, 120).fill(navyDark);

      // --- HEADER LOGO & SLOGAN ---
      doc.fillColor("#FFFFFF");
      doc.font("Helvetica-Bold").fontSize(26).text("TruthLens AI", 50, 40);
      doc.font("Helvetica-Oblique").fontSize(10).fillColor("#94A3B8").text("Detect. Explain. Trust.", 50, 70);

      // --- DOCUMENT TITLE ---
      doc.fillColor("#FFFFFF");
      doc.font("Helvetica-Bold").fontSize(14).text("FORENSIC VERIFICATION REPORT", 300, 55, { align: "right", width: 245 });

      // --- DIVIDER BAR ---
      doc.rect(50, 140, 495, 3).fill("#3B82F6"); // Accent Blue

      // --- SECTION 1: FILE DETAILS ---
      doc.fillColor(navyDark).font("Helvetica-Bold").fontSize(14).text("FILE METADATA", 50, y);
      y += 25;
      
      const drawMetaField = (label: string, value: string) => {
        doc.font("Helvetica").fontSize(10);
        const valHeight = doc.heightOfString(value, { width: 385 });
        const needed = Math.max(18, valHeight + 6);
        checkPageBreak(needed);
        doc.fillColor(textMuted).font("Helvetica-Bold").fontSize(10).text(label, 50, y, { width: 100 });
        doc.fillColor(textMain).font("Helvetica").fontSize(10).text(value, 160, y, { width: 385 });
        y += needed;
      };

      drawMetaField("File Name:", analysis.file_name);
      drawMetaField("Media Type:", analysis.file_type.toUpperCase());
      drawMetaField("Analysis Date:", new Date(analysis.timestamp).toLocaleString());
      drawMetaField("Report ID:", analysis.id);

      // --- SECTION 2 & 3: VERDICT & CONFIDENCE SCORE ---
      y += 15;
      checkPageBreak(90);
      doc.rect(50, y, 495, 80).fill(grayLight).strokeColor(grayBorder).stroke();

      const isAi = analysis.verdict === "AI-GENERATED";
      const verdictColor = isAi ? redVerdict : greenVerdict;

      // Verdict label & value
      doc.fillColor(navyDark).font("Helvetica-Bold").fontSize(11).text("VERIFICATION VERDICT", 70, y + 15);
      doc.fillColor(verdictColor).font("Helvetica-Bold").fontSize(20).text(analysis.verdict, 70, y + 33);

      // Confidence score block
      doc.fillColor(navyDark).font("Helvetica-Bold").fontSize(11).text("CONFIDENCE RATING", 380, y + 15);
      doc.fillColor(verdictColor).font("Helvetica-Bold").fontSize(28).text(`${analysis.confidence_score}%`, 380, y + 28);
      
      y += 105;

      // --- SECTION 4: DETAILED EXPLANATION ---
      checkPageBreak(60);
      doc.fillColor(navyDark).font("Helvetica-Bold").fontSize(14).text("EXECUTIVE FORENSIC SUMMARY", 50, y);
      y += 20;

      // Measure height of explanation accurately
      doc.font("Helvetica").fontSize(10.5);
      const explanationHeight = doc.heightOfString(analysis.explanation, {
        width: 495,
        lineGap: 4,
      });

      checkPageBreak(explanationHeight + 20);
      doc.fillColor(textMain).font("Helvetica").fontSize(10.5).text(analysis.explanation, 50, y, {
        align: "justify",
        width: 495,
        lineGap: 4,
      });
      y += explanationHeight + 25;

      // --- SECTION 5: SUSPICIOUS REGIONS / ANOMALIES ---
      const sectionTitle = isAi ? "DETECTED SYNTHETIC ANOMALIES" : "HUMAN METRIC VERIFICATIONS";
      checkPageBreak(40);
      doc.fillColor(navyDark).font("Helvetica-Bold").fontSize(14).text(sectionTitle, 50, y);
      y += 20;

      analysis.suspicious_regions.forEach((anomaly) => {
        doc.font("Helvetica").fontSize(10);
        const anomalyHeight = doc.heightOfString(anomaly, {
          width: 470,
          lineGap: 3,
        });

        checkPageBreak(anomalyHeight + 10);
        
        // Draw bullet point
        doc.circle(58, y + 5, 3).fill(verdictColor);
        doc.fillColor(textMain).font("Helvetica").fontSize(10).text(anomaly, 72, y, {
          width: 470,
          lineGap: 3,
        });
        
        y += anomalyHeight + 12;
      });

      // --- SCORE MATRIX (METADATA SCORES) ---
      if (analysis.metadata) {
        y += 15;
        const scores = Object.entries(analysis.metadata);
        const matrixHeight = 35 + scores.length * 20;
        checkPageBreak(matrixHeight);

        doc.fillColor(navyDark).font("Helvetica-Bold").fontSize(12).text("RISK INDEX SCORING MATRIX", 50, y);
        y += 20;

        // Draw simple bar chart
        scores.forEach(([key, val]) => {
          const cleanKey = key.replace("Score", "").toUpperCase();
          const scoreVal = val as number;
          
          doc.fillColor(textMain).font("Helvetica-Bold").fontSize(9).text(cleanKey, 50, y);
          
          // Draw grey background bar
          doc.rect(150, y - 2, 250, 10).fill("#E2E8F0");
          // Draw colored value bar
          const maxVal = cleanKey === "FRAME" ? 30 : cleanKey === "EXIF" ? 25 : 20;
          const barWidth = (scoreVal / maxVal) * 250;
          if (barWidth > 0) {
            doc.rect(150, y - 2, Math.min(barWidth, 250), 10).fill(isAi ? "#EF4444" : "#22C55E");
          }
          
          // Draw text score
          doc.fillColor(textMuted).font("Helvetica").fontSize(9).text(`${scoreVal} pts`, 415, y);
          y += 18;
        });
      }

      // --- FOOTER ON ALL PAGES ---
      const pages = doc.bufferedPageRange();
      for (let i = 0; i < pages.count; i++) {
        doc.switchToPage(i);
        doc.rect(50, 790, 495, 1).fill(grayBorder);
        doc.fillColor(textMuted).font("Helvetica").fontSize(8);
        doc.text("Generated by TruthLens AI | Confidential Forensic Verification Report", 50, 800);
        doc.text(`Page ${i + 1} of ${pages.count}`, 500, 800, { align: "right", width: 45 });
      }

      doc.end();
    } catch (err) {
      reject(err);
    }
  });
}
