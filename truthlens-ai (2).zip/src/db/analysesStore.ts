import fs from "fs";
import path from "path";
import { AnalysisRecord, User, BatchJob, FeedbackRecord } from "../types";

const DATA_DIR = path.join(process.cwd(), "data");
const USERS_FILE = path.join(DATA_DIR, "users.json");
const ANALYSES_FILE = path.join(DATA_DIR, "analyses.json");
const BATCH_JOBS_FILE = path.join(DATA_DIR, "batch_jobs.json");
const REPORTS_FILE = path.join(DATA_DIR, "reports.json");
const FEEDBACK_FILE = path.join(DATA_DIR, "feedback.json");

// Ensure data directory and all collections files exist
function initializeStore() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  const files = [USERS_FILE, ANALYSES_FILE, BATCH_JOBS_FILE, REPORTS_FILE, FEEDBACK_FILE];
  for (const file of files) {
    if (!fs.existsSync(file)) {
      fs.writeFileSync(file, JSON.stringify([], null, 2), "utf-8");
    }
  }
}

// Helper to read a collection file
function readCollection<T>(filePath: string): T[] {
  initializeStore();
  try {
    const content = fs.readFileSync(filePath, "utf-8");
    return JSON.parse(content) as T[];
  } catch (err) {
    return [];
  }
}

// Helper to write a collection file
function writeCollection<T>(filePath: string, data: T[]) {
  initializeStore();
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2), "utf-8");
}

// ============================================================================
// USERS COLLECTION
// ============================================================================
export async function save_user(user: Omit<User, "id" | "created_at"> & { id?: string }): Promise<User> {
  const users = readCollection<User>(USERS_FILE);
  const newId = user.id || Math.random().toString(36).substring(2, 15);
  const newUser: User = {
    ...user,
    id: newId,
    created_at: new Date().toISOString()
  };
  users.push(newUser);
  writeCollection(USERS_FILE, users);
  return newUser;
}

export async function get_user_by_email(email: string): Promise<User | null> {
  const users = readCollection<User>(USERS_FILE);
  const found = users.find(u => u.email.toLowerCase() === email.toLowerCase());
  return found || null;
}

export async function get_user_by_id(id: string): Promise<User | null> {
  const users = readCollection<User>(USERS_FILE);
  const found = users.find(u => u.id === id);
  return found || null;
}

// ============================================================================
// ANALYSES COLLECTION
// ============================================================================
export async function save_analysis(data: Omit<AnalysisRecord, "id" | "timestamp" | "risk_level"> & { id?: string }): Promise<AnalysisRecord> {
  const analyses = readCollection<AnalysisRecord>(ANALYSES_FILE);

  // Risk Level Logic:
  // - confidence_score 0-40 → Risk: LOW (green)
  // - confidence_score 41-70 → Risk: MEDIUM (yellow/orange)
  // - confidence_score 71-100 → Risk: HIGH (red)
  const score = data.confidence_score;
  let risk: "LOW" | "MEDIUM" | "HIGH" = "LOW";
  if (score >= 71) {
    risk = "HIGH";
  } else if (score >= 41) {
    risk = "MEDIUM";
  }

  const newDoc: AnalysisRecord = {
    ...data,
    risk_level: risk,
    id: data.id || Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15),
    timestamp: new Date().toISOString(),
  };

  analyses.push(newDoc);
  writeCollection(ANALYSES_FILE, analyses);
  return newDoc;
}

export async function get_all_analyses(userId?: string): Promise<AnalysisRecord[]> {
  const analyses = readCollection<AnalysisRecord>(ANALYSES_FILE);
  let filtered = analyses;
  if (userId) {
    filtered = analyses.filter(a => a.user_id === userId);
  }
  // Return sorted by latest first (Timestamp index optimization)
  return filtered.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
}

export async function get_analysis_by_id(id: string): Promise<AnalysisRecord | null> {
  const analyses = readCollection<AnalysisRecord>(ANALYSES_FILE);
  const found = analyses.find((doc) => doc.id === id);
  return found || null;
}

export async function get_analysis_by_filename(fileName: string): Promise<AnalysisRecord | null> {
  const analyses = readCollection<AnalysisRecord>(ANALYSES_FILE);
  const lower = fileName.toLowerCase();
  
  // Try exact match first
  let found = analyses.find((doc) => doc.file_name.toLowerCase() === lower);
  if (!found) {
    // Try partial match
    found = analyses.find((doc) => {
      const docLower = doc.file_name.toLowerCase();
      return lower.includes(docLower) || docLower.includes(lower);
    });
  }
  return found || null;
}

// ============================================================================
// BATCH JOBS COLLECTION
// ============================================================================
export async function save_batch_job(data: Omit<BatchJob, "id" | "created_at">): Promise<BatchJob> {
  const jobs = readCollection<BatchJob>(BATCH_JOBS_FILE);
  const newJob: BatchJob = {
    ...data,
    id: "batch_" + Math.random().toString(36).substring(2, 15),
    created_at: new Date().toISOString()
  };
  jobs.push(newJob);
  writeCollection(BATCH_JOBS_FILE, jobs);
  return newJob;
}

export async function get_batch_job_by_id(id: string): Promise<BatchJob | null> {
  const jobs = readCollection<BatchJob>(BATCH_JOBS_FILE);
  const found = jobs.find(j => j.id === id);
  return found || null;
}

// ============================================================================
// FEEDBACK COLLECTION
// ============================================================================
export async function save_feedback(data: Omit<FeedbackRecord, "id" | "timestamp">): Promise<FeedbackRecord> {
  const feedbacks = readCollection<FeedbackRecord>(FEEDBACK_FILE);
  const newFeedback: FeedbackRecord = {
    ...data,
    id: "feed_" + Math.random().toString(36).substring(2, 15),
    timestamp: new Date().toISOString()
  };
  feedbacks.push(newFeedback);
  writeCollection(FEEDBACK_FILE, feedbacks);
  return newFeedback;
}

export async function get_feedback_by_analysis_id(analysisId: string): Promise<FeedbackRecord[]> {
  const feedbacks = readCollection<FeedbackRecord>(FEEDBACK_FILE);
  return feedbacks.filter(f => f.analysis_id === analysisId);
}
