import { AnalysisRecord, User, BatchJob, FeedbackRecord } from "../types";

// Support both localhost:8000 backend mapping and relative paths for the Cloud Run preview environment
const BASE_URL = typeof window !== "undefined" && (window.location.hostname === "localhost" || window.location.hostname === "127.0.0.1") && window.location.port !== "3000"
  ? "http://localhost:8000"
  : "";

function getHeaders(contentType?: string): Record<string, string> {
  const headers: Record<string, string> = {};
  if (contentType) {
    headers["Content-Type"] = contentType;
  }
  const token = localStorage.getItem("truthlens_token");
  if (token) {
    headers["Authorization"] = `Bearer ${token}`;
  }
  return headers;
}

export async function detectImage(file: File): Promise<AnalysisRecord> {
  const formData = new FormData();
  formData.append("file", file);

  const response = await fetch(`${BASE_URL}/api/detect/image`, {
    method: "POST",
    headers: getHeaders(),
    body: formData,
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || `Server responded with status ${response.status}`);
  }

  return response.json();
}

export async function detectAudio(file: File): Promise<AnalysisRecord> {
  const formData = new FormData();
  formData.append("file", file);

  const response = await fetch(`${BASE_URL}/api/detect/audio`, {
    method: "POST",
    headers: getHeaders(),
    body: formData,
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || `Server responded with status ${response.status}`);
  }

  return response.json();
}

export async function detectVideo(file: File): Promise<AnalysisRecord> {
  const formData = new FormData();
  formData.append("file", file);

  const response = await fetch(`${BASE_URL}/api/detect/video`, {
    method: "POST",
    headers: getHeaders(),
    body: formData,
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || `Server responded with status ${response.status}`);
  }

  return response.json();
}

export async function getAnalysis(id: string): Promise<AnalysisRecord> {
  const response = await fetch(`${BASE_URL}/api/analyses/${id}`, {
    headers: getHeaders()
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || `Failed to fetch analysis with status ${response.status}`);
  }
  return response.json();
}

export async function getAllAnalyses(): Promise<AnalysisRecord[]> {
  const response = await fetch(`${BASE_URL}/api/analyses`, {
    headers: getHeaders()
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || `Failed to fetch analyses logs`);
  }
  return response.json();
}

export function getReportDownloadUrl(id: string): string {
  const token = localStorage.getItem("truthlens_token") || "";
  return `${BASE_URL}/api/report/${id}?token=${encodeURIComponent(token)}`;
}

export function downloadReport(id: string): string {
  return getReportDownloadUrl(id);
}

// --- AUTH API HELPMATES ---
export async function registerUser(email: string, name: string, password_raw: string): Promise<{ token: string; user: User }> {
  const response = await fetch(`${BASE_URL}/api/auth/register`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, name, password: password_raw })
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || "Failed to register user");
  }
  return response.json();
}

export async function loginUser(email: string, password_raw: string): Promise<{ token: string; user: User }> {
  const response = await fetch(`${BASE_URL}/api/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password: password_raw })
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || "Failed to authenticate");
  }
  return response.json();
}

export async function fetchCurrentUser(): Promise<User> {
  const response = await fetch(`${BASE_URL}/api/auth/me`, {
    headers: getHeaders()
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || "Failed to retrieve user session");
  }
  return response.json();
}

// --- BATCH PROCESSING API ---
export async function uploadBatch(files: File[]): Promise<BatchJob> {
  const formData = new FormData();
  for (const file of files) {
    formData.append("files", file);
  }

  const response = await fetch(`${BASE_URL}/api/detect/batch`, {
    method: "POST",
    headers: getHeaders(),
    body: formData
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || "Failed to process batch files");
  }
  return response.json();
}

export async function getBatchDetails(batchId: string): Promise<BatchJob & { expandedResults: AnalysisRecord[] }> {
  const response = await fetch(`${BASE_URL}/api/batch/${batchId}`, {
    headers: getHeaders()
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || "Failed to load batch job details");
  }
  return response.json();
}

export function getBatchReportDownloadUrl(batchId: string): string {
  const token = localStorage.getItem("truthlens_token") || "";
  return `${BASE_URL}/api/batch/${batchId}/report?token=${encodeURIComponent(token)}`;
}

// --- ANALYTICS API ---
export async function fetchAnalytics(): Promise<any> {
  const response = await fetch(`${BASE_URL}/api/analytics`, {
    headers: getHeaders()
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || "Failed to retrieve analytics data");
  }
  return response.json();
}

// --- SHARE API ---
export async function shareReport(id: string, method: "email" | "whatsapp", recipient: string): Promise<any> {
  const response = await fetch(`${BASE_URL}/api/report/${id}/share`, {
    method: "POST",
    headers: getHeaders("application/json"),
    body: JSON.stringify({ method, recipient })
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || "Failed to share report");
  }
  return response.json();
}

// --- FEEDBACK API ---
export async function submitFeedback(analysisId: string, correction: string, comment: string): Promise<any> {
  const response = await fetch(`${BASE_URL}/api/feedback`, {
    method: "POST",
    headers: getHeaders("application/json"),
    body: JSON.stringify({ analysis_id: analysisId, user_correction: correction, comment })
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || "Failed to submit feedback");
  }
  return response.json();
}

// --- PUBLIC VERIFICATION API ---
export async function verifyPublicHash(id: string): Promise<any> {
  const response = await fetch(`${BASE_URL}/api/verify/${id}`);
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || "Cryptographic verification failed or record not found");
  }
  return response.json();
}
