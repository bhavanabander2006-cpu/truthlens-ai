import React, { createContext, useContext, useState, useEffect } from "react";
import { User } from "../types";
import { loginUser, registerUser, fetchCurrentUser } from "./api";

interface AuthContextType {
  user: User | null;
  token: string | null;
  loading: boolean;
  login: (email: string, password_raw: string) => Promise<void>;
  register: (email: string, name: string, password_raw: string) => Promise<void>;
  logout: () => void;
  loginWithGoogleToken: (token: string) => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem("truthlens_token"));
  const [loading, setLoading] = useState(true);

  const logout = () => {
    localStorage.removeItem("truthlens_token");
    setToken(null);
    setUser(null);
  };

  useEffect(() => {
    async function loadUser() {
      if (token) {
        try {
          const fetched = await fetchCurrentUser();
          setUser(fetched);
        } catch (e) {
          console.error("Session restore failed:", e);
          logout();
        }
      }
      setLoading(false);
    }
    loadUser();
  }, [token]);

  const login = async (email: string, password_raw: string) => {
    const res = await loginUser(email, password_raw);
    localStorage.setItem("truthlens_token", res.token);
    setToken(res.token);
    setUser(res.user);
  };

  const register = async (email: string, name: string, password_raw: string) => {
    const res = await registerUser(email, name, password_raw);
    localStorage.setItem("truthlens_token", res.token);
    setToken(res.token);
    setUser(res.user);
  };

  const loginWithGoogleToken = (googleToken: string) => {
    localStorage.setItem("truthlens_token", googleToken);
    setToken(googleToken);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        loading,
        login,
        register,
        logout,
        loginWithGoogleToken,
        isAuthenticated: !!user,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
