export interface BenchmarkSample {
  name: string;
  label: string;
  type: "AI-GENERATED" | "HUMAN-GENERATED";
  desc: string;
  model: string;
}

export const SAMPLE_PLAYGROUND: Record<"image" | "audio" | "video", BenchmarkSample[]> = {
  image: [
    { name: "midjourney_cyberpunk_city.png", label: "Midjourney Cyberpunk City", type: "AI-GENERATED", desc: "Generated using Midjourney v6. Highly realistic synthetic structures.", model: "FFT Spectral Noise peaks detected" },
    { name: "dalle3_astronaut_riding_horse.png", label: "DALL-E 3 Astronaut Riding Horse", type: "AI-GENERATED", desc: "Generated using DALL-E 3. Inconsistent edge shading lines.", model: "JPEG compression (ELA) mismatch" },
    { name: "thispersondoesnotexist_ai_face.png", label: "ThisPersonDoesNotExist Face", type: "AI-GENERATED", desc: "StyleGAN human face simulation. Artificial ear iris details.", model: "Synthesized pupil coordinate alignment" },
    { name: "stable_diffusion_fantasy_landscape.png", label: "Stable Diffusion Landscape", type: "AI-GENERATED", desc: "Generated using Stable Diffusion XL. Dreamlike landscape with surreal illumination vectors.", model: "Synthetic light transport noise" },
    { name: "adobe_firefly_steampunk_robot.png", label: "Adobe Firefly Steampunk Robot", type: "AI-GENERATED", desc: "Generated using Adobe Firefly. Rich, inorganic geometric details.", model: "Generative texture vector analysis" },
    { name: "selfie_iphone_camera.jpg", label: "Selfie iPhone Camera", type: "HUMAN-GENERATED", desc: "Authentic selfie captured with hardware sensor camera.", model: "Genuine camera EXIF headers verified" },
    { name: "landscape_nature_sunset.jpg", label: "Landscape Nature Sunset", type: "HUMAN-GENERATED", desc: "Landscape photography with natural physical lens aperture.", model: "Continuous light spectrum waves" },
    { name: "scanned_old_vintage_photo.jpg", label: "Scanned Old Vintage Photo", type: "HUMAN-GENERATED", desc: "Physical film photograph scan. Real paper fiber grain noise.", model: "Organic grain density verification" },
    { name: "gopro_underwater_swimmer.jpg", label: "GoPro Underwater Swimmer", type: "HUMAN-GENERATED", desc: "GoPro action camera frame with authentic light refraction.", model: "Physical refraction vector matching" },
    { name: "canon_dslr_portrait_photo.jpg", label: "Canon DSLR Portrait", type: "HUMAN-GENERATED", desc: "Studio portrait with optical bokeh and fine skin pore noise.", model: "Canon optical sensor chromatic bokeh" }
  ],
  audio: [
    { name: "elevenlabs_voice_clone.mp3", label: "ElevenLabs Voice Clone", type: "AI-GENERATED", desc: "Synthesized clone of an executive speech. Low prosody pitch.", model: "Deepfake Mel-Frequency cepstrum score" },
    { name: "google_tts_voice_assistant.mp3", label: "Google Assistant TTS", type: "AI-GENERATED", desc: "Google WaveNet Speech synthesis engine output.", model: "Perfect background zero noise floor" },
    { name: "suno_ai_music_track.mp3", label: "Suno AI Music Track", type: "AI-GENERATED", desc: "Suno v3 generated instrumental and vocal audio song.", model: "Artificial pitch envelope compression" },
    { name: "udio_generated_ambient_song.mp3", label: "Udio Generated Ambient Song", type: "AI-GENERATED", desc: "Udio AI music generation system output.", model: "Artificial frequency comb spacing" },
    { name: "vimeo_ai_narration_voice.mp3", label: "Vimeo AI Narration Voice", type: "AI-GENERATED", desc: "Vimeo AI video editor voiceover tool output.", model: "Digital phase vocoder grid alignment" },
    { name: "recorded_phone_memo.wav", label: "Recorded Phone Memo", type: "HUMAN-GENERATED", desc: "Standard microphone recording of human voice dictation.", model: "Physiological breath pauses detected" },
    { name: "noisy_recording_background_noise.wav", label: "Noisy Voice Background", type: "HUMAN-GENERATED", desc: "Voice capture in a crowded environment with natural hums.", model: "Authentic spatial acoustic reverb" },
    { name: "real_voice_quiet_recording.wav", label: "Quiet Human Recording", type: "HUMAN-GENERATED", desc: "Clean studio room vocal narration without synthesis.", model: "Dynamic organic vocal formant changes" },
    { name: "outdoor_forest_birds_chirping.wav", label: "Outdoor Forest Ambience", type: "HUMAN-GENERATED", desc: "Field recording of a biological forest canopy.", model: "Non-linear wildlife auditory spectrum" },
    { name: "acoustic_guitar_live_session.wav", label: "Acoustic Guitar Live Session", type: "HUMAN-GENERATED", desc: "Acoustic guitar live session with realistic room echo.", model: "Authentic mechanical string friction signature" }
  ],
  video: [
    { name: "sora_generated_video_city.mp4", label: "Sora Generated Video City", type: "AI-GENERATED", desc: "Synthesized hyper-realistic city drone stream by OpenAI Sora.", model: "Frame-by-frame interpolation warp" },
    { name: "runway_ai_video_cinematic.mp4", label: "Runway AI Cinematic Video", type: "AI-GENERATED", desc: "Short dynamic movie trailer shot created with Runway Gen-2.", model: "Inconsistent physical fluid dynamics" },
    { name: "deepfake_video_faceswap.mp4", label: "Deepfake Faceswap Stream", type: "AI-GENERATED", desc: "Celebrity face swap video model using DeepFaceLab tools.", model: "Unnatural facial border pixel blending" },
    { name: "pika_labs_cartoon_animation.mp4", label: "Pika Labs Cartoon Animation", type: "AI-GENERATED", desc: "Slick 3D animated sequence generated by Pika Labs.", model: "Synthetic animation keyframe drift" },
    { name: "heygen_talking_avatar_presenter.mp4", label: "HeyGen Talking Avatar", type: "AI-GENERATED", desc: "AI corporate spokesperson video by HeyGen.", model: "Static neck posture and blink sync score" },
    { name: "normal_video_phone_camera.mp4", label: "Normal Phone Video Camera", type: "HUMAN-GENERATED", desc: "Handheld smartphone video showing realistic movement jitter.", model: "Genuine optical camera sensor flow" },
    { name: "screen_recording_tutorial.mp4", label: "Screen Recording Tutorial", type: "HUMAN-GENERATED", desc: "Desktop application screencast with unmanipulated frames.", model: "Linear digital pixel raster grid" },
    { name: "iphone_video_captured_live.mp4", label: "iPhone Live Video Capture", type: "HUMAN-GENERATED", desc: "High-definition live video recorded with natural exposure shifts.", model: "Real dynamic lighting exposure adjustments" },
    { name: "gopro_biking_trail_recording.mp4", label: "GoPro Biking Trail Recording", type: "HUMAN-GENERATED", desc: "First-person action clip from a helmet-mounted GoPro.", model: "Physical lens vibration pattern" },
    { name: "dashcam_car_driving_highway.mp4", label: "Dashcam Car Highway Driving", type: "HUMAN-GENERATED", desc: "Continuous highway dashcam footage with periodic windshield glare.", model: "Windshield glare refraction metric" }
  ]
};
